import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_bluetooth_serial_plus/flutter_bluetooth_serial_plus.dart';
import '../core/app_settings.dart';
import '../models/vehicle.dart';
import '../services/bluetooth_service.dart';
import '../services/obd_service.dart';
import 'dashboard_screen.dart';
import 'settings_screen.dart';
import 'vehicle_selector_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  bool _isLoading = false;
  String _connectionMode = 'bluetooth';
  final TextEditingController _hostController = TextEditingController(text: '192.168.0.10');
  final TextEditingController _portController = TextEditingController(text: '35000');

  @override
  void initState() { super.initState(); WidgetsBinding.instance.addPostFrameCallback((_) => _initBluetooth()); }

  @override
  void dispose() { _hostController.dispose(); _portController.dispose(); super.dispose(); }

  Future<void> _initBluetooth() async {
    final bt = context.read<BluetoothService>();
    final granted = await bt.requestPermissions();
    if (granted) {
      if (!await bt.isBluetoothEnabled()) await bt.enableBluetooth();
      await bt.loadBondedDevices();
    }
  }

  Future<void> _connectToDevice(BluetoothDevice device) async {
    setState(() => _isLoading = true);
    final bt = context.read<BluetoothService>();
    final obd = context.read<OBDService>();
    final connected = await bt.connect(device);
    if (connected) {
      await Future.delayed(const Duration(milliseconds: 500));
      final initialized = await obd.initialize();
      if (initialized && mounted) {
        Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const DashboardScreen()));
      } else if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(obd.lastError ?? 'OBD initialization failed'), backgroundColor: Colors.red.shade700));
        await bt.disconnect();
      }
    } else if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(bt.errorMessage ?? 'Connection failed'), backgroundColor: Colors.red.shade700));
    }
    if (mounted) setState(() => _isLoading = false);
  }

  Future<void> _connectWifi() async {
    final host = _hostController.text.trim();
    final port = int.tryParse(_portController.text.trim());
    if (host.isEmpty || port == null || port < 1 || port > 65535) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Adresse IP ou port TCP invalide.')));
      return;
    }
    setState(() => _isLoading = true);
    final bt = context.read<BluetoothService>();
    final obd = context.read<OBDService>();
    final connected = await bt.connectWifi(host, port);
    if (connected) {
      await Future.delayed(const Duration(milliseconds: 250));
      final initialized = await obd.initialize();
      if (initialized && mounted) {
        Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const DashboardScreen()));
      } else if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(obd.lastError ?? 'OBD initialization failed'), backgroundColor: Colors.red.shade700));
        await bt.disconnect();
      }
    } else if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(bt.errorMessage ?? 'Wi-Fi connection failed'), backgroundColor: Colors.red.shade700));
    }
    if (mounted) setState(() => _isLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<AppSettings>();
    final vehicle = VehicleCatalog.byId(settings.selectedVehicleId);
    return Scaffold(
      appBar: AppBar(title: Text(tr(context, 'app_name'), style: const TextStyle(fontWeight: FontWeight.w800, letterSpacing: .5)), actions: [
        IconButton(icon: const Icon(Icons.tune_rounded), tooltip: tr(context, 'advanced'), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsScreen()))),
      ]),
      body: Consumer<BluetoothService>(builder: (context, bt, _) {
        if (_isLoading) return Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [const CircularProgressIndicator(), const SizedBox(height: 22), Text(tr(context, 'connecting')), const SizedBox(height: 8), Text(tr(context, 'ignition'), style: Theme.of(context).textTheme.bodySmall)]));
        return RefreshIndicator(onRefresh: _initBluetooth, child: ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 24), children: [
          _vehicleCard(context, vehicle),
          const SizedBox(height: 12),
          Card(child: Padding(padding: const EdgeInsets.all(16), child: Row(children: [
            CircleAvatar(radius: 24, backgroundColor: Theme.of(context).colorScheme.primaryContainer, child: Icon(Icons.tune_rounded, color: Theme.of(context).colorScheme.primary)),
            const SizedBox(width: 14), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(tr(context, 'advanced'), style: const TextStyle(fontWeight: FontWeight.bold)), const SizedBox(height: 4), Text(_scanSummary(context, settings.scanOptions), style: Theme.of(context).textTheme.bodySmall)])),
            IconButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsScreen())), icon: const Icon(Icons.chevron_right)),
          ]))),
          const SizedBox(height: 18),
          Text(tr(context, 'connection_mode'), style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          SegmentedButton<String>(
            segments: [
              ButtonSegment(value: 'bluetooth', label: Text(tr(context, 'bluetooth')), icon: const Icon(Icons.bluetooth)),
              ButtonSegment(value: 'wifi', label: Text(tr(context, 'wifi_tcp')), icon: const Icon(Icons.wifi)),
            ],
            selected: {_connectionMode},
            onSelectionChanged: (selection) => setState(() { _connectionMode = selection.first; if (_connectionMode == 'bluetooth') _initBluetooth(); }),
          ),
          const SizedBox(height: 12),
          if (_connectionMode == 'wifi') ...[
            Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              TextField(controller: _hostController, keyboardType: TextInputType.url, autocorrect: false, decoration: InputDecoration(labelText: tr(context, 'wifi_host'), prefixIcon: const Icon(Icons.router))),
              const SizedBox(height: 10),
              TextField(controller: _portController, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: tr(context, 'wifi_port'), prefixIcon: const Icon(Icons.settings_ethernet))),
              const SizedBox(height: 10),
              Text(tr(context, 'wifi_hint'), style: Theme.of(context).textTheme.bodySmall),
              const SizedBox(height: 14),
              FilledButton.icon(onPressed: _isLoading ? null : _connectWifi, icon: const Icon(Icons.link), label: Text(tr(context, 'connect_wifi'))),
            ]))),
          ] else ...[
            Row(children: [Expanded(child: Text(tr(context, 'paired'), style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold))), IconButton(onPressed: _initBluetooth, icon: const Icon(Icons.refresh), tooltip: tr(context, 'refresh'))]),
            if (bt.bondedDevices.isEmpty) _emptyDevices(context) else ...bt.bondedDevices.map((d) => _deviceTile(context, d)),
            const SizedBox(height: 10),
            Text(tr(context, 'tip'), textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodySmall),
          ],
        ]));
      }),
    );
  }

  Widget _vehicleCard(BuildContext context, VehicleModel? vehicle) {
    if (vehicle == null) return Card(child: InkWell(onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const VehicleSelectorScreen())), borderRadius: BorderRadius.circular(18), child: Padding(padding: const EdgeInsets.all(18), child: Row(children: [CircleAvatar(radius: 27, child: const Icon(Icons.directions_car_outlined)), const SizedBox(width: 14), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(tr(context, 'select_vehicle'), style: const TextStyle(fontWeight: FontWeight.bold)), const SizedBox(height: 4), Text(tr(context, 'choose_model'), style: Theme.of(context).textTheme.bodySmall)])), const Icon(Icons.chevron_right)]))));
    return Card(clipBehavior: Clip.antiAlias, child: InkWell(onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const VehicleSelectorScreen())), child: SizedBox(height: 150, child: Row(children: [Expanded(flex: 5, child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [Text(tr(context, 'selected_vehicle'), style: Theme.of(context).textTheme.bodySmall), const SizedBox(height: 6), Text('${vehicle.brand} ${vehicle.model}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)), const SizedBox(height: 5), Text('${vehicle.year} • ${vehicle.body}', style: Theme.of(context).textTheme.bodySmall), const SizedBox(height: 10), Text(tr(context, 'change'), style: TextStyle(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.w700))])), Expanded(flex: 5, child: Container(color: Theme.of(context).colorScheme.surfaceContainerHighest, child: Image.asset(vehicle.image, fit: BoxFit.contain)))]))));
  }

  String _scanSummary(BuildContext context, ScanOptions o) => [if (o.liveData) tr(context, 'live_data'), if (o.confirmedDtc) tr(context, 'confirmed_dtc'), if (o.pendingDtc) tr(context, 'pending_dtc'), if (o.fullPidScan) tr(context, 'full_pid')].join(' • ');

  Widget _emptyDevices(BuildContext context) => Card(child: Padding(padding: const EdgeInsets.all(24), child: Column(children: [Icon(Icons.bluetooth_disabled, size: 56, color: Theme.of(context).colorScheme.outline), const SizedBox(height: 14), Text(tr(context, 'no_devices'), style: const TextStyle(fontWeight: FontWeight.w700)), const SizedBox(height: 8), Text(tr(context, 'bluetooth_help'), textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodySmall), const SizedBox(height: 16), FilledButton.icon(onPressed: _initBluetooth, icon: const Icon(Icons.refresh), label: Text(tr(context, 'refresh')))])));

  Widget _deviceTile(BuildContext context, BluetoothDevice device) {
    final name = device.name ?? 'Bluetooth';
    final isObd = RegExp(r'OBD|ELM|V-LINK|VLINK|OBDII|OBD2', caseSensitive: false).hasMatch(name);
    return Card(margin: const EdgeInsets.only(bottom: 8), child: ListTile(contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5), leading: CircleAvatar(backgroundColor: isObd ? Theme.of(context).colorScheme.primaryContainer : Theme.of(context).colorScheme.surfaceContainerHighest, child: Icon(isObd ? Icons.car_repair : Icons.bluetooth)), title: Text(name, style: const TextStyle(fontWeight: FontWeight.w700)), subtitle: Text(device.address, style: Theme.of(context).textTheme.bodySmall), trailing: const Icon(Icons.chevron_right), onTap: () => _connectToDevice(device));
  }
}
