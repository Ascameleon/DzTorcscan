import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/app_settings.dart';
import '../services/bluetooth_service.dart';
import '../services/obd_service.dart';
import '../models/pid_data.dart';
import 'dtc_screen.dart';
import 'home_screen.dart';
import 'vehicle_info_screen.dart';

class DashboardScreen extends StatefulWidget { const DashboardScreen({super.key}); @override State<DashboardScreen> createState() => _DashboardScreenState(); }
class _DashboardScreenState extends State<DashboardScreen> {
  @override void initState() { super.initState(); WidgetsBinding.instance.addPostFrameCallback((_) => _start()); }
  Future<void> _start() async { final settings = context.read<AppSettings>(); final obd = context.read<OBDService>(); if (settings.scanOptions.confirmedDtc) await obd.readDTCs(); if (settings.scanOptions.pendingDtc) await obd.readPendingDTCs(); await obd.startLiveScan(options: settings.scanOptions); }
  Future<void> _disconnect() async { final obd = context.read<OBDService>(); final bt = context.read<BluetoothService>(); obd.stopLiveScan(); await bt.disconnect(); if (mounted) Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const HomeScreen()), (_) => false); }
  @override Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: Text(tr(context, 'app_name')), leading: IconButton(icon: const Icon(Icons.power_settings_new), tooltip: tr(context,'disconnect'), onPressed: _disconnect), actions: [IconButton(icon: const Icon(Icons.memory_outlined), tooltip: tr(context,'diagnostic'), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const VehicleInfoScreen()))), IconButton(icon: const Icon(Icons.warning_amber_rounded), tooltip: tr(context,'fault_codes'), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DTCScreen())).then((_) { if (mounted) _start(); }))]), body: Consumer2<OBDService,BluetoothService>(builder: (context,obd,bt,_) {
      if (!bt.isConnected) return Center(child: Text(tr(context,'disconnect')));
      final data=obd.liveData;
      return Column(children:[Container(width:double.infinity,padding:const EdgeInsets.symmetric(horizontal:16,vertical:10),child:Row(children:[Container(width:9,height:9,decoration:BoxDecoration(color:obd.isScanning?Theme.of(context).colorScheme.primary:Colors.orange,shape:BoxShape.circle)),const SizedBox(width:9),Expanded(child:Text(bt.connectionLabel)),Text(obd.isScanning?tr(context,'live'):tr(context,'pause'),style:TextStyle(fontWeight:FontWeight.bold,color:obd.isScanning?Theme.of(context).colorScheme.primary:Colors.orange))])),if(obd.lastError!=null) MaterialBanner(content:Text(obd.lastError!),leading:const Icon(Icons.error_outline),actions:[TextButton(onPressed:_start,child:Text(tr(context,'retry')))]),Expanded(child:GridView.count(padding:const EdgeInsets.all(12),crossAxisCount:2,mainAxisSpacing:12,crossAxisSpacing:12,childAspectRatio:1.2,children:[_g(tr(context,'rpm'),'010C',data['010C'],Icons.speed),_g(tr(context,'speed'),'010D',data['010D'],Icons.directions_car),_g(tr(context,'coolant'),'0105',data['0105'],Icons.thermostat),_g(tr(context,'load'),'0104',data['0104'],Icons.donut_large),_g(tr(context,'throttle'),'0111',data['0111'],Icons.swipe_up),_g(tr(context,'voltage'),'0142',data['0142'],Icons.battery_charging_full),_g(tr(context,'map'),'010B',data['010B'],Icons.compress),_g(tr(context,'fuel'),'012F',data['012F'],Icons.local_gas_station)])])]);
    });
  }
  Widget _g(String title,String pid,PIDData? data,IconData icon){final accent=data?.available==false?Theme.of(context).colorScheme.outline:Theme.of(context).colorScheme.primary;return Card(child:Padding(padding:const EdgeInsets.all(15),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Row(children:[Icon(icon,size:18,color:accent),const SizedBox(width:8),Expanded(child:Text(title,style:TextStyle(color:Theme.of(context).colorScheme.onSurfaceVariant),overflow:TextOverflow.ellipsis))]),const Spacer(),Text(data?.displayValue??'—',style:TextStyle(fontSize:30,fontWeight:FontWeight.bold,color:accent)),const SizedBox(height:4),Text(data?.unit??PIDDefinitions.getUnit(pid),style:TextStyle(fontSize:12,color:Theme.of(context).colorScheme.onSurfaceVariant))])));}
}
