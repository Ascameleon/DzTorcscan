import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import '../models/pid_data.dart';
import '../core/app_settings.dart';
import 'bluetooth_service.dart';
import 'obd_protocol.dart';

class OBDService extends ChangeNotifier {
  final BluetoothService _bluetooth;
  StreamSubscription? _dataSubscription;
  final StringBuffer _buffer = StringBuffer();
  Completer<String>? _responseCompleter;
  Future<void> _commandTail = Future.value();

  bool _isInitialized = false;
  bool _isScanning = false;
  bool _initializing = false;
  String? _protocol;
  String? _lastError;
  final Map<String, PIDData> _liveData = {};
  List<DTCCode> _dtcCodes = [];
  List<DTCCode> _pendingDtcCodes = [];
  String? _confirmedDtcError;
  String? _pendingDtcError;
  Set<String> _supportedPids = {};
  VehicleCapabilities _capabilities = const VehicleCapabilities();

  bool get isInitialized => _isInitialized;
  bool get isScanning => _isScanning;
  bool get initializing => _initializing;
  String? get protocol => _protocol;
  String? get lastError => _lastError;
  Map<String, PIDData> get liveData => Map.unmodifiable(_liveData);
  List<DTCCode> get dtcCodes => List.unmodifiable(_dtcCodes);
  List<DTCCode> get pendingDtcCodes => List.unmodifiable(_pendingDtcCodes);
  String? get dtcReadError {
    final errors = [
      if (_confirmedDtcError != null) _confirmedDtcError!,
      if (_pendingDtcError != null) _pendingDtcError!,
    ];
    return errors.isEmpty ? null : errors.join('\n');
  }
  Set<String> get supportedPids => Set.unmodifiable(_supportedPids);
  VehicleCapabilities get capabilities => _capabilities;

  OBDService(this._bluetooth) {
    _bluetooth.addListener(_onBluetoothChanged);
  }

  void _onBluetoothChanged() {
    if (!_bluetooth.isConnected) {
      _resetState();
      notifyListeners();
    }
  }

  void _resetState() {
    _isInitialized = false;
    _isScanning = false;
    _initializing = false;
    _liveData.clear();
    _dtcCodes = [];
    _pendingDtcCodes = [];
    _confirmedDtcError = null;
    _pendingDtcError = null;
    _supportedPids = {};
    _capabilities = const VehicleCapabilities();
    // Release any command waiting for an adapter prompt immediately when the
    // transport disappears; otherwise every pending operation waits for timeout.
    _completeResponse('DISCONNECTED');
    _dataSubscription?.cancel();
    _dataSubscription = null;
    _responseCompleter = null;
    _buffer.clear();
    _protocol = null;
  }

  Future<bool> initialize() async {
    if (!_bluetooth.isConnected || _initializing) return false;
    _initializing = true;
    _lastError = null;
    notifyListeners();

    try {
      _startListener();
      await _sendCommand('ATZ', timeout: const Duration(seconds: 8));
      await Future.delayed(const Duration(milliseconds: 1200));
      await _sendCommand('ATE0');
      await _sendCommand('ATL0');
      await _sendCommand('ATS0');
      await _sendCommand('ATH0');
      await _sendCommand('ATSP0');

      final protocol = await _sendCommand('ATDP', timeout: const Duration(seconds: 5));
      _protocol = _cleanProtocol(protocol);

      final first = await _sendCommand('0100', timeout: const Duration(seconds: 8));
      if (ObdProtocol.isNegative(first)) {
        throw StateError('Le calculateur ne répond pas. Vérifiez le contact, le connecteur OBD et l’adaptateur.');
      }
      _supportedPids = ObdProtocol.decodeSupportedPids(first, 0x0100);

      for (final base in const [0x0120, 0x0140, 0x0160]) {
        final pid = base.toRadixString(16).padLeft(4, '0').toUpperCase();
        try {
          final response = await _sendCommand(pid, timeout: const Duration(seconds: 5));
          _supportedPids.addAll(ObdProtocol.decodeSupportedPids(response, base));
        } catch (_) {
          // Some ECUs simply don't implement the next supported-PID block.
        }
      }

      _capabilities = VehicleCapabilities(
        supportedPids: _supportedPids,
        protocol: _protocol,
        obdStandard: _supportedPids.contains('011C') ? await _readObdStandard() : null,
      );
      _isInitialized = true;
      _initializing = false;
      notifyListeners();
      return true;
    } catch (e) {
      _initializing = false;
      _isInitialized = false;
      _lastError = e is StateError ? e.message : 'Initialisation OBD impossible : $e';
      notifyListeners();
      return false;
    }
  }

  String _cleanProtocol(String response) {
    final value = response.replaceAll(RegExp(r'[\r\n>]'), ' ').replaceAll(RegExp(r'\s+'), ' ').trim();
    return value.isEmpty ? 'Auto' : value;
  }

  Future<String?> _readObdStandard() async {
    try {
      final response = await _sendCommand('011C');
      final bytes = ObdProtocol.findPidData(response, '011C', length: 1);
      if (bytes.isEmpty) return null;
      const standards = {
        1: 'OBD-II',
        2: 'OBD',
        3: 'OBD + OBD-II',
        4: 'OBD-I',
        5: 'NO OBD',
        6: 'EOBD',
        7: 'EOBD + OBD-II',
        8: 'EOBD + OBD',
        9: 'EOBD + OBD + OBD-II',
        10: 'JOBD',
        11: 'JOBD + OBD-II',
        12: 'JOBD + EOBD',
        13: 'JOBD + EOBD + OBD-II',
      };
      return standards[bytes.first] ?? 'Standard ${bytes.first}';
    } catch (_) {
      return null;
    }
  }

  void _startListener() {
    _dataSubscription?.cancel();
    _buffer.clear();
    final stream = _bluetooth.inputStream;
    if (stream == null) throw StateError('Flux Bluetooth indisponible');
    _dataSubscription = stream.listen(
      (data) => _onBytes(data),
      onError: (Object error) {
        _lastError = 'Flux adaptateur OBD2 interrompu : $error';
        _completeResponse('ERROR: $error');
        _bluetooth.markTransportEnded(reason: _lastError, failed: true);
        notifyListeners();
      },
      onDone: () {
        _isInitialized = false;
        _isScanning = false;
        _lastError = 'Connexion à l’adaptateur OBD2 interrompue.';
        _completeResponse('DISCONNECTED');
        _bluetooth.markTransportEnded(reason: _lastError);
        notifyListeners();
      },
      cancelOnError: false,
    );
  }

  void _onBytes(List<int> data) {
    final text = utf8.decode(data, allowMalformed: true);
    _buffer.write(text);
    final raw = _buffer.toString();
    final prompt = raw.indexOf('>');
    if (prompt >= 0) {
      final response = raw.substring(0, prompt);
      _buffer
        ..clear()
        ..write(raw.substring(prompt + 1));
      _completeResponse(response);
    }
  }

  void _completeResponse(String response) {
    final completer = _responseCompleter;
    if (completer != null && !completer.isCompleted) completer.complete(response);
  }

  Future<String> _sendCommand(String command, {Duration timeout = const Duration(seconds: 4)}) {
    final result = Completer<String>();
    final previous = _commandTail;
    _commandTail = previous.then<void>((_) async {
      try {
        final response = await _executeCommand(command, timeout: timeout);
        if (!result.isCompleted) result.complete(response);
      } catch (e, st) {
        if (!result.isCompleted) result.completeError(e, st);
      }
    }, onError: (_, __) async {
      try {
        final response = await _executeCommand(command, timeout: timeout);
        if (!result.isCompleted) result.complete(response);
      } catch (e, st) {
        if (!result.isCompleted) result.completeError(e, st);
      }
    });
    return result.future;
  }

  Future<String> _executeCommand(String command, {required Duration timeout}) async {
    if (!_bluetooth.isConnected) throw StateError('Adaptateur OBD2 non connecté');
    _responseCompleter = Completer<String>();
    _buffer.clear();
    await _bluetooth.write('${command.trim()}\r');
    try {
      final response = await _responseCompleter!.future.timeout(timeout);
      return response.replaceAll('>', '').trim();
    } on TimeoutException {
      _responseCompleter = null;
      _buffer.clear();
      throw TimeoutException('Timeout de la commande $command', timeout);
    } finally {
      _responseCompleter = null;
    }
  }

  Future<PIDData?> readPID(String pid) async {
    if (!_isInitialized || !_bluetooth.isConnected) return null;
    final normalized = pid.toUpperCase();
    final definition = PIDDefinitions.get(normalized);
    if (definition == null) return null;
    if (_supportedPids.isNotEmpty && !_supportedPids.contains(normalized)) {
      _liveData[normalized] = PIDData(
        pid: normalized,
        name: definition.name,
        unit: definition.unit,
        value: null,
        displayValue: 'N/D',
        available: false,
      );
      notifyListeners();
      return _liveData[normalized];
    }

    try {
      final response = await _sendCommand(normalized);
      final bytes = ObdProtocol.findPidData(response, normalized, length: definition.bytes);
      final value = bytes.length >= definition.bytes && definition.decoder != null ? definition.decoder!(bytes) : null;
      final display = value == null ? '—' : _formatValue(value, definition.unit);
      final data = PIDData(
        pid: normalized,
        name: definition.name,
        unit: definition.unit,
        value: value,
        displayValue: display,
      );
      _liveData[normalized] = data;
      notifyListeners();
      return data;
    } catch (e) {
      debugPrint('PID $normalized: $e');
      return null;
    }
  }

  String _formatValue(double value, String unit) {
    final decimals = unit == 'V' || unit == 'g/s' || unit == '°' || unit == '%' || unit == '°C' ? 1 : 0;
    return value.toStringAsFixed(decimals);
  }

  Future<void> startLiveScan({ScanOptions options = const ScanOptions()}) async {
    if (!_isInitialized || _isScanning) return;
    _isScanning = true;
    notifyListeners();

    final preferred = <String>[
      ...PIDDefinitions.fastPids,
      '0105',
      '010F',
      '010B',
      '0110',
      '012F',
      '0146',
    ];
    final pids = <String>[];
    for (final pid in preferred) {
      if (!pids.contains(pid) && (_supportedPids.isEmpty || _supportedPids.contains(pid))) pids.add(pid);
    }
    if (options.fullPidScan) {
      for (final pid in PIDDefinitions.all.keys) {
        if ((_supportedPids.isEmpty || _supportedPids.contains(pid)) && !pids.contains(pid)) pids.add(pid);
      }
    }
    if (pids.isEmpty) pids.addAll(PIDDefinitions.fastPids);

    if (options.fullPidScan) {
      for (final pid in pids) {
        if (!_isScanning) break;
        await readPID(pid);
      }
    }

    while (_isScanning && _bluetooth.isConnected && _isInitialized) {
      if (!options.liveData) break;
      for (final pid in pids) {
        if (!_isScanning) break;
        await readPID(pid);
      }
      await Future.delayed(Duration(milliseconds: options.liveRefreshMs));
    }
    _isScanning = false;
    notifyListeners();
  }

  void stopLiveScan() {
    _isScanning = false;
    notifyListeners();
  }

  Future<List<DTCCode>> readDTCs() async {
    if (!_isInitialized) return [];
    stopLiveScan();
    try {
      final response = await _sendCommand('03', timeout: const Duration(seconds: 8));
      if (ObdProtocol.isFailure(response)) {
        _confirmedDtcError = 'Lecture des codes confirmés impossible : ${response.trim()}';
        _lastError = _confirmedDtcError;
        notifyListeners();
        return [];
      }
      _dtcCodes = _makeDtcList(ObdProtocol.parseDtc(response, 0x03));
      _confirmedDtcError = null;
      _lastError = _pendingDtcError;
      notifyListeners();
      return _dtcCodes;
    } catch (e) {
      _confirmedDtcError = 'Lecture des codes confirmés impossible : $e';
      _lastError = _confirmedDtcError;
      notifyListeners();
      return [];
    }
  }

  Future<List<DTCCode>> readPendingDTCs() async {
    if (!_isInitialized) return [];
    try {
      final response = await _sendCommand('07', timeout: const Duration(seconds: 8));
      if (ObdProtocol.isFailure(response)) {
        _pendingDtcError = 'Lecture des codes en attente impossible : ${response.trim()}';
        _lastError = _pendingDtcError;
        notifyListeners();
        return [];
      }
      _pendingDtcCodes = _makeDtcList(ObdProtocol.parseDtc(response, 0x07), pending: true);
      _pendingDtcError = null;
      _lastError = _confirmedDtcError;
      notifyListeners();
      return _pendingDtcCodes;
    } catch (e) {
      _pendingDtcError = 'Lecture des codes en attente impossible : $e';
      _lastError = _pendingDtcError;
      notifyListeners();
      return [];
    }
  }

  List<DTCCode> _makeDtcList(List<String> codes, {bool pending = false}) => codes
      .map((code) => DTCCode(code: code, description: _getDTCDescription(code), isPending: pending))
      .toList();

  Future<bool> clearDTCs() async {
    if (!_isInitialized) return false;
    stopLiveScan();
    try {
      final response = await _sendCommand('04', timeout: const Duration(seconds: 8));
      final normalized = ObdProtocol.normalize(response);
      if (!normalized.contains('44')) {
        _lastError = 'Le calculateur n’a pas confirmé l’effacement.';
        notifyListeners();
        return false;
      }
      _dtcCodes = [];
      _pendingDtcCodes = [];
      _confirmedDtcError = null;
      _pendingDtcError = null;
      _lastError = null;
      notifyListeners();
      return true;
    } catch (e) {
      _lastError = 'Effacement des codes impossible : $e';
      notifyListeners();
      return false;
    }
  }

  String _getDTCDescription(String code) {
    const descriptions = {
      'P0100': 'Débitmètre d’air (MAF) — circuit',
      'P0113': 'Température d’air admission — signal élevé',
      'P0118': 'Température liquide refroidissement — signal élevé',
      'P0128': 'Température liquide refroidissement hors plage / thermostat',
      'P0130': 'Sonde lambda B1S1 — circuit',
      'P0131': 'Sonde lambda B1S1 — tension basse',
      'P0132': 'Sonde lambda B1S1 — tension haute',
      'P0171': 'Mélange trop pauvre — banque 1',
      'P0172': 'Mélange trop riche — banque 1',
      'P0174': 'Mélange trop pauvre — banque 2',
      'P0175': 'Mélange trop riche — banque 2',
      'P0300': 'Ratés d’allumage aléatoires / multiples',
      'P0301': 'Ratés d’allumage — cylindre 1',
      'P0302': 'Ratés d’allumage — cylindre 2',
      'P0303': 'Ratés d’allumage — cylindre 3',
      'P0304': 'Ratés d’allumage — cylindre 4',
      'P0401': 'Débit EGR insuffisant',
      'P0402': 'Débit EGR excessif',
      'P0420': 'Efficacité catalyseur sous le seuil — banque 1',
      'P0430': 'Efficacité catalyseur sous le seuil — banque 2',
      'P0442': 'Petite fuite détectée — système EVAP',
      'P0455': 'Grosse fuite détectée — système EVAP',
      'P0500': 'Capteur de vitesse véhicule',
      'P0562': 'Tension système trop basse',
      'P0563': 'Tension système trop élevée',
      'P0700': 'Transmission — demande de voyant défaut',
    };
    return descriptions[code] ?? 'Code défaut $code — description standard non embarquée';
  }

  @override
  void dispose() {
    _isScanning = false;
    _dataSubscription?.cancel();
    _bluetooth.removeListener(_onBluetoothChanged);
    super.dispose();
  }
}
