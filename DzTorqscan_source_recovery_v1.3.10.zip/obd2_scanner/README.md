## Transport modes

Dz Torqscan 1.3.10 supports paired Bluetooth Classic and configurable Wi-Fi TCP connections to compatible ELM327 adapters. The common Wi-Fi default is 192.168.0.10:35000, but adapter values vary.

# Dz Torqscan 1.3.10

Application Android de diagnostic OBD-II via Bluetooth Classic / RFCOMM avec adaptateurs ELM327. Nom affiché : Dz Torqscan.

## Ce qui est implémenté

- Connexion aux appareils Bluetooth classiques appairés.
- Gestion des permissions Android Bluetooth (connexion aux appareils déjà appairés, sans permission de scan inutile).
- Initialisation ELM327 : `ATZ`, `ATE0`, `ATL0`, `ATS0`, `ATH0`, `ATSP0`.
- Détection du protocole réel avec `ATDP`.
- Test ECU et découverte des blocs de PIDs supportés (`0100`, `0120`, `0140`, `0160`).
- File de commandes série : une commande OBD à la fois, avec timeout.
- Parsing robuste des réponses ELM terminées par `>`.
- Décodage des principaux PIDs standard : régime, vitesse, température, charge, accélérateur, MAP, MAF, carburant, tension, avance, etc.
- Tableau de bord live adaptatif aux PIDs réellement supportés.
- Lecture des DTC confirmés (Mode 03).
- Lecture des DTC en attente (Mode 07).
- Effacement des DTC (Mode 04) avec confirmation de la réponse `44`.
- Écran diagnostic : protocole, standard OBD et PIDs détectés.
- Tests unitaires du moteur de parsing OBD/DTC.
- Android uniquement pour cette version : le plugin Bluetooth utilisé est Bluetooth Classic/RFCOMM.

## Point important : produit réel vs validation terrain

Le moteur OBD est codé pour communiquer avec un ELM327 réel, mais aucune connexion physique à un véhicule/ELM327 n'est disponible dans l'environnement de développement utilisé pour préparer cette archive. Par conséquent, la communication ECU réelle, la compatibilité de chaque véhicule et la stabilité sur route doivent encore être validées avec du matériel.

Dz Torqscan ne fabrique pas de valeur lorsqu'un PID n'est pas disponible : l'interface affiche `N/D` ou `—`.

## Environnement recommandé

- Flutter stable récent (la branche actuelle de Flutter est recommandée).
- Android Studio / Android SDK.
- Android 8+ recommandé.
- Adaptateur ELM327 Bluetooth Classic fiable.
- Véhicule compatible OBD-II.

Le plugin `flutter_bluetooth_serial_plus` est utilisé pour le transport Bluetooth Classic/RFCOMM et a été choisi plutôt que l'ancien `flutter_bluetooth_serial`, notamment parce que sa branche récente a reçu des mises à jour Android/Gradle en 2026.

## Installation

```bash
flutter pub get
flutter analyze
flutter test
flutter run
```

Pour un APK release :

```bash
flutter build apk --release
```

## Procédure véhicule

1. Brancher l'adaptateur OBD-II.
2. Mettre le contact.
3. Appairer l'adaptateur dans Android.
4. Ouvrir Dz Torqscan.
5. Sélectionner l'adaptateur.
6. Attendre la détection du protocole et des PIDs.
7. Vérifier le tableau de bord.
8. Ouvrir « Codes défauts » pour les modes 03/07/04.

## Architecture

```text
lib/
├── main.dart
├── models/
│   └── pid_data.dart
├── services/
│   ├── bluetooth_service.dart
│   ├── obd_protocol.dart
│   └── obd_service.dart
└── screens/
    ├── home_screen.dart
    ├── dashboard_screen.dart
    ├── dtc_screen.dart
    └── vehicle_info_screen.dart
```

## Sécurité d'utilisation

L'effacement des DTC est une opération réelle sur le calculateur. Il ne faut pas utiliser Dz Torqscan pour masquer un défaut avant diagnostic/réparation. L'application ne prétend pas remplacer un outil constructeur ou un diagnostic professionnel sur les calculateurs propriétaires.

## Validation finale nécessaire

Avant publication commerciale, effectuer sur plusieurs véhicules et adaptateurs :

- connexion/déconnexion répétée ;
- moteurs essence/diesel ;
- protocoles ISO 15765-4 CAN et autres protocoles OBD-II courants ;
- réponses multi-trames ;
- DTC 03/07/04 ;
- PID supportés/non supportés ;
- pertes Bluetooth ;
- tests prolongés du live scan ;
- Android 8 à version Android actuelle ;
- plusieurs modèles d'ELM327, notamment éviter les clones instables.


## Dz Torqscan 1.2 — interface et configuration

Cette version ajoute :
- interface Material 3 épurée, claire par défaut avec thème sombre optionnel ;
- français, anglais et arabe avec RTL pour l'arabe ;
- sélection du véhicule (marque, modèle, année, carrosserie) avec illustration locale du véhicule ;
- options de scan avancé : données temps réel, DTC confirmés/en attente, scan complet des PIDs supportés et fréquence de rafraîchissement ;
- conservation de la règle de fiabilité : aucune valeur OBD non reçue de l'ECU n'est inventée.

Les illustrations de véhicules sont des visuels intégrés à l'application, destinés à identifier le choix de modèle ; elles ne constituent pas des photos officielles des constructeurs.


## Correctif de parsing OBD

Le service positif OBD est désormais converti en hexadécimal avant la recherche de réponse (par exemple `01` devient `41`, pas `65`). Des tests de régression couvrent le matching des PIDs, le régime moteur, les blocs de PIDs et les DTC.

## Compilation automatisée

Le workflow `.github/workflows/android-apk.yml` exécute `flutter pub get`, `flutter analyze`, `flutter test` et `flutter build apk --release`, puis publie l'APK comme artefact GitHub Actions. Il faut placer ce projet dans un dépôt GitHub et lancer le workflow. Ce paquet source n'est pas lui-même un APK et aucune compilation réelle n'est revendiquée tant que le workflow n'a pas réussi.


### v1.3.2 Wi-Fi endpoint safety

The Wi-Fi transport validates IPv4/IPv6 literals and DNS hostnames before opening a socket, rejects URL schemes/paths and invalid ports, and formats IPv6 endpoints unambiguously. Dedicated regression tests are in `test/connection_endpoint_test.dart`.


### v1.3.4 — pending-command disconnect recovery

When the transport disconnects, any outstanding OBD command now receives a terminal `DISCONNECTED` response immediately instead of waiting for its command timeout. The protocol label is also cleared so the interface cannot retain a stale protocol from the previous adapter session.


### v1.3.7 — stricter IPv6 endpoint notation

Bracket notation is accepted only for valid IPv6 literals. Bracketed hostnames and mismatched brackets are rejected before opening a TCP connection; regression tests cover these cases.


### v1.3.8 — least-privilege Android permissions

The manifest no longer requests Bluetooth scanning or location permissions. The app only connects to devices already paired in Android settings, so it requests `BLUETOOTH_CONNECT` at runtime on supported Android versions and keeps Wi-Fi TCP access via `INTERNET`.


### v1.3.9 — truthful DTC empty state

When both confirmed and pending DTC scans are disabled in Advanced Scan settings, the DTC screen now states that the scan is disabled instead of incorrectly implying that the ECU has no faults. French, English, and Arabic labels are included.


### v1.3.10 — CI build-toolchain alignment

The GitHub Actions fallback now copies the Android settings file from the same installed Flutter template as its Gradle wrapper. This keeps the Android Gradle Plugin and Gradle distribution aligned when archived source bundles do not contain wrapper files.
