#!/usr/bin/env python3
"""Offline preflight checks for the Dz Torqscan source archive."""
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
errors = []

manifest = ROOT / 'android/app/src/main/AndroidManifest.xml'
try:
    ET.parse(manifest)
except Exception as exc:
    errors.append(f'Android manifest XML invalid: {exc}')

pubspec = ROOT / 'pubspec.yaml'
try:
    import yaml
    data = yaml.safe_load(pubspec.read_text(encoding='utf-8'))
    assert data['name'] == 'torqscan'
    assert 'flutter' in data['dependencies']
except ImportError:
    # YAML is checked separately by CI using Flutter's pub resolver.
    print('WARN: PyYAML unavailable; pubspec validation deferred to Flutter CI')
except Exception as exc:
    errors.append(f'pubspec.yaml invalid: {exc}')

for rel in ['lib/services/obd_protocol.dart', 'lib/services/obd_service.dart', 'lib/services/bluetooth_service.dart', 'lib/screens/home_screen.dart']:
    p = ROOT / rel
    if not p.is_file() or not p.read_text(encoding='utf-8').strip():
        errors.append(f'Missing or empty source file: {rel}')

assets = ROOT / 'assets/vehicles'
for name in ['peugeot_208.png', 'renault_clio.png', 'dacia_sandero.png', 'vw_golf.png', 'toyota_corolla.png', 'mercedes_c.png', 'hyundai_tucson.png', 'generic_obd.png']:
    if not (assets / name).is_file():
        errors.append(f'Missing vehicle asset: {name}')

protocol = (ROOT / 'lib/services/obd_protocol.dart').read_text(encoding='utf-8')
if "toRadixString(16)" not in protocol or "positiveService" not in protocol:
    errors.append('Positive OBD service hex conversion fix not found')

tests = (ROOT / 'test/obd_protocol_test.dart').read_text(encoding='utf-8')
for token in [
    'matches positive service',
    'decode RPM',
    'decode DTC',
    'decodes supported PID blocks',
    'multiple ECU response lines without merging frames',
    'deduplicates repeated DTCs across ECU response lines',
    'keeps valid ECU DTCs when another ECU returns NO DATA',
    'does not merge PID payload across ECU response lines',
    'distinguishes empty DTC response from adapter failure',
    'unions supported PIDs reported by multiple ECUs',
]:
    if token not in tests:
        errors.append(f'Missing protocol test group: {token}')

if "response.split(RegExp(r'[\\r\\n]+'))" not in protocol:
    errors.append('DTC parser no longer preserves ECU response line boundaries')
if "for (final line in response.split(RegExp(r'[\\r\\n]+')))" not in protocol:
    errors.append('PID parser no longer preserves ECU response line boundaries')
if 'static bool isFailure(String response)' not in protocol:
    errors.append('OBD adapter failure classifier missing')
dtc_screen = (ROOT / 'lib/screens/dtc_screen.dart').read_text(encoding='utf-8')
if "tr(context, hasError ? 'read_failed' : 'no_fault')" not in dtc_screen or 'obd.dtcReadError' not in dtc_screen:
    errors.append('DTC screen may report no faults after a read failure')
settings_source_all = (ROOT / 'lib/core/app_settings.dart').read_text(encoding='utf-8')
for lang in ['fr', 'en', 'ar']:
    section_start = settings_source_all.find(f"    '{lang}': {{")
    section_end = settings_source_all.find('\n    },', section_start)
    section = settings_source_all[section_start:section_end] if section_start >= 0 and section_end >= 0 else ''
    for key in ['read_failed', 'obd_not_ready', 'clear_success', 'clear_failed']:
        if f"'{key}':" not in section:
            errors.append(f'Missing {key} translation for {lang}')

# BuildContext.read/watch/select are extension methods from provider; guard against missing import.
settings_source = (ROOT / 'lib/core/app_settings.dart').read_text(encoding='utf-8')
if re.search(r'\bcontext\.(?:read|watch|select)\s*<', settings_source) and "import 'package:provider/provider.dart';" not in settings_source:
    errors.append('lib/core/app_settings.dart uses provider BuildContext extensions but is missing provider import')

# Wi-Fi TCP transport must remain present alongside paired Bluetooth.
transport_source = (ROOT / 'lib/services/bluetooth_service.dart').read_text(encoding='utf-8')
home_source = (ROOT / 'lib/screens/home_screen.dart').read_text(encoding='utf-8')
manifest_source = manifest.read_text(encoding='utf-8')
for token in ['void markTransportEnded({String? reason, bool failed = false})', 'BluetoothConnectionState.error : BluetoothConnectionState.disconnected', 'if (socket != null && !socket.destroyed) socket.destroy()']:
    if token not in transport_source:
        errors.append(f'Missing transport lifecycle recovery: {token}')
obd_service_source = (ROOT / 'lib/services/obd_service.dart').read_text(encoding='utf-8')
for token in ["_bluetooth.markTransportEnded(reason: _lastError, failed: true)", "_bluetooth.markTransportEnded(reason: _lastError)", 'Connexion à l’adaptateur OBD2 interrompue']:
    if token not in obd_service_source:
        errors.append(f'Missing OBD stream termination handling: {token}')
for token in ["_completeResponse('DISCONNECTED')", '_protocol = null;']:
    if token not in obd_service_source:
        errors.append(f'Missing pending-command disconnect recovery: {token}')

for token in ['Future<bool> connectWifi(String host, int port)', 'Socket.connect(normalizedHost, port', 'socket.add(bytes)', 'Stream<Uint8List>? get inputStream']:
    if token not in transport_source:
        errors.append(f'Missing Wi-Fi TCP transport feature: {token}')
for token in ["'wifi_host'", "'wifi_port'", "'connect_wifi'", "connectWifi(host, port)"]:
    source_to_check = settings_source_all + home_source
    if token not in source_to_check:
        errors.append(f'Missing Wi-Fi connection UI/localization: {token}')
if 'android.permission.INTERNET' not in manifest_source:
    errors.append('Android INTERNET permission missing for Wi-Fi TCP')
if 'android.permission.BLUETOOTH_SCAN' in manifest_source:
    errors.append('Bluetooth SCAN permission is unnecessary for paired-device-only workflow')
if 'android.permission.ACCESS_FINE_LOCATION' in manifest_source or 'android.permission.ACCESS_COARSE_LOCATION' in manifest_source:
    errors.append('Location permission is unnecessary for paired-device-only workflow')
for icon in [
    'android/app/src/main/res/mipmap-mdpi/ic_launcher.png',
    'android/app/src/main/res/mipmap-hdpi/ic_launcher.png',
    'android/app/src/main/res/mipmap-xhdpi/ic_launcher.png',
    'android/app/src/main/res/mipmap-xxhdpi/ic_launcher.png',
    'android/app/src/main/res/mipmap-xxxhdpi/ic_launcher.png',
    'android/app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml',
    'android/app/src/main/res/mipmap-anydpi-v26/ic_launcher_round.xml',
]:
    if not (ROOT / icon).is_file():
        errors.append(f'Missing launcher icon resource: {icon}')
if 'android.hardware.bluetooth" android:required="false"' not in manifest_source:
    errors.append('Bluetooth hardware must be optional when Wi-Fi transport is supported')

bluetooth = (ROOT / 'lib/services/bluetooth_service.dart').read_text(encoding='utf-8')
permission_section = bluetooth.split('Future<bool> requestPermissions()', 1)[-1].split('Future<bool> isBluetoothEnabled()', 1)[0]
if 'Permission.bluetoothConnect' not in permission_section:
    errors.append('Android Bluetooth CONNECT runtime permission request missing')
if 'Permission.bluetoothScan' in permission_section:
    errors.append('Unneeded Bluetooth SCAN runtime permission blocks paired-device-only workflow')

# Validate the pure-Dart Wi-Fi endpoint guard and its regression tests.
endpoint = (ROOT / 'lib/services/connection_endpoint.dart').read_text(encoding='utf-8')
endpoint_tests = (ROOT / 'test/connection_endpoint_test.dart').read_text(encoding='utf-8')
for token in ['InternetAddress.tryParse(host)', "host.contains(':')", 'port < 1 || port > 65535', 'String get label', "final bracketed = host.startsWith('[') || host.endsWith(']')", 'bracketLiteral.type != InternetAddressType.IPv6']:
    if token not in endpoint:
        errors.append(f'Missing Wi-Fi endpoint validation rule: {token}')
for token in ['trims valid IPv4 adapter addresses', 'accepts DNS hostnames', 'accepts IPv6', 'rejects bracketed DNS names', 'rejects URL schemes', 'rejects ports outside the TCP range']:
    if token not in endpoint_tests:
        errors.append(f'Missing endpoint regression test: {token}')
if "import 'connection_endpoint.dart';" not in transport_source or 'ConnectionEndpoint.parse(host, port)' not in transport_source:
    errors.append('Wi-Fi transport is not using the endpoint validator')


# The DTC screen must not equate disabled scanning with a clean ECU.
dtc_screen_source = (ROOT / 'lib/screens/dtc_screen.dart').read_text(encoding='utf-8')
if 'final dtcScanDisabled = !scanOptions.confirmedDtc && !scanOptions.pendingDtc;' not in dtc_screen_source:
    errors.append('DTC screen does not detect when both DTC scans are disabled')
if "tr(context, 'dtc_scan_disabled')" not in dtc_screen_source:
    errors.append('DTC screen does not show a distinct disabled-scan state')
for lang in ['fr', 'en', 'ar']:
    section_start = settings_source_all.find(f"    '{lang}': {{")
    section_end = settings_source_all.find('\n    },', section_start)
    section = settings_source_all[section_start:section_end] if section_start >= 0 and section_end >= 0 else ''
    for key in ['dtc_scan_disabled', 'dtc_scan_disabled_desc']:
        if f"'{key}':" not in section:
            errors.append(f'Missing {key} translation for {lang}')

# CI must align the wrapper and Android plugin settings from one Flutter template.
workflow_path = ROOT / '.github/workflows/android-apk.yml'
try:
    workflow_text = workflow_path.read_text(encoding='utf-8')
    for token in [
        'flutter create --platforms=android --project-name torqscan --org com.example /tmp/torqscan-wrapper',
        'cp /tmp/torqscan-wrapper/android/gradle/wrapper/* android/gradle/wrapper/',
        'cp /tmp/torqscan-wrapper/android/settings.gradle android/settings.gradle',
        'flutter pub get',
        'flutter analyze --no-pub',
        'flutter test --no-pub',
        'flutter build apk --release --no-pub',
        'actions/upload-artifact@v4',
    ]:
        if token not in workflow_text:
            errors.append(f'Android CI workflow missing build safeguard/step: {token}')
except Exception as exc:
    errors.append(f'Could not read Android CI workflow: {exc}')

# Keep archive/release metadata internally consistent.
status = ROOT / 'BUILD_STATUS.md'
try:
    version_line = next(line for line in pubspec.read_text(encoding='utf-8').splitlines() if line.startswith('version:'))
    version = version_line.split(':', 1)[1].strip().split('+', 1)[0]
    status_text = status.read_text(encoding='utf-8')
    if f'Dz Torqscan {version} — build and validation status' not in status_text:
        errors.append(f'Build status title does not match pubspec version {version}')
except Exception as exc:
    errors.append(f'Could not verify release metadata consistency: {exc}')

if errors:
    print('PREFLIGHT FAILED')
    print('\n'.join(f'- {e}' for e in errors))
    sys.exit(1)
print('PREFLIGHT PASSED: XML, source presence, vehicle assets, OBD protocol tests, least-privilege Bluetooth permissions, launcher resources, and Wi-Fi TCP transport markers, endpoint validation, and endpoint test coverage checked.')
print('NOTE: This is not a substitute for flutter analyze, flutter test, APK build, or hardware testing.')
