# Dz Torqscan 1.4.0

Application Android de **diagnostic OBD-II** via adaptateurs **ELM327** (Bluetooth Classic RFCOMM et Wi-Fi TCP).

## Fonctionnalités

- Connexion Bluetooth (appareils déjà appairés) et Wi-Fi TCP
- Initialisation ELM327 + détection protocole (`ATDP`)
- Découverte des PIDs supportés (multi-ECU)
- Tableau de bord live (régime, vitesse, température, charge, accélérateur, tension, MAP, carburant…)
- Lecture DTC confirmés (Mode 03) et en attente (Mode 07)
- Effacement des codes (Mode 04)
- **Mode démo** intégré (simulation sans matériel)
- Interface FR / EN / AR + thème clair / sombre
- Sélection de véhicule (plusieurs modèles + générique)

## Prérequis

- Flutter stable récent
- Android 8+ recommandé
- Adaptateur ELM327 Bluetooth Classic ou Wi-Fi
- Véhicule compatible OBD-II

## Installation

```bash
cd dztorqscan   # ou le dossier du projet
flutter pub get
flutter run
```

Build APK release :

```bash
flutter build apk --release
```

## Utilisation

1. Appairez l’adaptateur OBD2 dans les réglages Bluetooth du téléphone  
   **ou** connectez-vous au Wi-Fi de l’adaptateur (souvent `192.168.0.10:35000`)
2. Ouvrez Dz Torqscan → choisissez le mode de connexion
3. Sélectionnez l’appareil / entrez l’IP → le scan démarre
4. Sans matériel : utilisez **« Essayer en mode démo »**

## Structure

```
lib/
  core/          # Paramètres, traductions
  models/        # PID, véhicule, DTC
  screens/       # Accueil, dashboard, DTC, réglages
  services/      # Bluetooth, OBD protocole, OBD service
android/         # Projet Android (applicationId: com.dztorqscan.app)
```

## Notes importantes

- Le moteur OBD est conçu pour un ELM327 réel. Validez toujours sur véhicule.
- L’app n’invente pas de valeurs : si un PID est absent → `—` / `N/D`.
- `applicationId` : `com.dztorqscan.app` (prêt pour publication, hors signature Play Store).

## Licence

Usage personnel / projet indépendant. Adaptez selon vos besoins.
