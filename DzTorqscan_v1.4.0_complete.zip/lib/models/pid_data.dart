class PIDData {
  final String pid;
  final String name;
  final String unit;
  final double? value;
  final String? displayValue;
  final DateTime timestamp;
  final bool available;

  PIDData({
    required this.pid,
    required this.name,
    required this.unit,
    this.value,
    this.displayValue,
    DateTime? timestamp,
    this.available = true,
  }) : timestamp = timestamp ?? DateTime.now();

  PIDData copyWith({
    String? pid,
    String? name,
    String? unit,
    double? value,
    String? displayValue,
    DateTime? timestamp,
    bool? available,
  }) => PIDData(
        pid: pid ?? this.pid,
        name: name ?? this.name,
        unit: unit ?? this.unit,
        value: value ?? this.value,
        displayValue: displayValue ?? this.displayValue,
        timestamp: timestamp ?? this.timestamp,
        available: available ?? this.available,
      );
}

class DTCCode {
  final String code;
  final String description;
  final bool isPending;

  const DTCCode({
    required this.code,
    required this.description,
    this.isPending = false,
  });
}

class VehicleCapabilities {
  final Set<String> supportedPids;
  final String? protocol;
  final int? ecuCount;
  final String? obdStandard;

  const VehicleCapabilities({
    this.supportedPids = const {},
    this.protocol,
    this.ecuCount,
    this.obdStandard,
  });

  bool supports(String pid) => supportedPids.contains(pid.toUpperCase());
}

class PIDDefinition {
  final String pid;
  final String name;
  final String unit;
  final int bytes;
  final double Function(List<int> bytes)? decoder;
  final String Function(List<int> bytes)? formatter;
  final bool fast;

  const PIDDefinition({
    required this.pid,
    required this.name,
    required this.unit,
    required this.bytes,
    this.decoder,
    this.formatter,
    this.fast = false,
  });
}

class PIDDefinitions {
  static double _one(List<int> b) => b[0].toDouble();
  static double _u16(List<int> b) => ((b[0] << 8) | b[1]).toDouble();
  static double _pct(List<int> b) => b[0] * 100 / 255;
  static double _temp(List<int> b) => b[0] - 40.0;

  static final Map<String, PIDDefinition> all = {
    '0101': PIDDefinition(pid: '0101', name: 'MIL / défauts', unit: '', bytes: 4, fast: false),
    '0104': PIDDefinition(pid: '0104', name: 'Charge moteur', unit: '%', bytes: 1, decoder: _pct, fast: true),
    '0105': PIDDefinition(pid: '0105', name: 'Temp. liquide refroidissement', unit: '°C', bytes: 1, decoder: _temp, fast: true),
    '0106': PIDDefinition(pid: '0106', name: 'Correction carburant court terme B1', unit: '%', bytes: 1, decoder: (b) => (b[0] - 128) * 100 / 128),
    '0107': PIDDefinition(pid: '0107', name: 'Correction carburant long terme B1', unit: '%', bytes: 1, decoder: (b) => (b[0] - 128) * 100 / 128),
    '010A': PIDDefinition(pid: '010A', name: 'Pression carburant', unit: 'kPa', bytes: 1, decoder: (b) => b[0] * 3),
    '010B': PIDDefinition(pid: '010B', name: 'Pression collecteur', unit: 'kPa', bytes: 1, decoder: _one),
    '010C': PIDDefinition(pid: '010C', name: 'Régime moteur', unit: 'RPM', bytes: 2, decoder: (b) => _u16(b) / 4, fast: true),
    '010D': PIDDefinition(pid: '010D', name: 'Vitesse véhicule', unit: 'km/h', bytes: 1, decoder: _one, fast: true),
    '010E': PIDDefinition(pid: '010E', name: 'Avance à l’allumage', unit: '°', bytes: 1, decoder: (b) => b[0] / 2 - 64),
    '010F': PIDDefinition(pid: '010F', name: 'Temp. air admission', unit: '°C', bytes: 1, decoder: _temp),
    '0110': PIDDefinition(pid: '0110', name: 'Débit massique air', unit: 'g/s', bytes: 2, decoder: (b) => _u16(b) / 100),
    '0111': PIDDefinition(pid: '0111', name: 'Position accélérateur', unit: '%', bytes: 1, decoder: _pct, fast: true),
    '011C': PIDDefinition(pid: '011C', name: 'Norme OBD', unit: '', bytes: 1),
    '011F': PIDDefinition(pid: '011F', name: 'Temps depuis démarrage', unit: 's', bytes: 2, decoder: _u16),
    '0121': PIDDefinition(pid: '0121', name: 'Distance avec MIL', unit: 'km', bytes: 2, decoder: _u16),
    '012F': PIDDefinition(pid: '012F', name: 'Niveau carburant', unit: '%', bytes: 1, decoder: _pct),
    '0131': PIDDefinition(pid: '0131', name: 'Distance depuis effacement', unit: 'km', bytes: 2, decoder: _u16),
    '0133': PIDDefinition(pid: '0133', name: 'Pression atmosphérique', unit: 'kPa', bytes: 1, decoder: _one),
    '0142': PIDDefinition(pid: '0142', name: 'Tension module contrôle', unit: 'V', bytes: 2, decoder: (b) => _u16(b) / 1000, fast: true),
    '0143': PIDDefinition(pid: '0143', name: 'Charge absolue', unit: '%', bytes: 2, decoder: (b) => _u16(b) * 100 / 25500),
    '0145': PIDDefinition(pid: '0145', name: 'Position accélérateur relative', unit: '%', bytes: 1, decoder: _pct),
    '0146': PIDDefinition(pid: '0146', name: 'Temp. ambiante', unit: '°C', bytes: 1, decoder: _temp),
    '014C': PIDDefinition(pid: '014C', name: 'Actionneur papillon', unit: '%', bytes: 1, decoder: _pct),
  };

  static PIDDefinition? get(String pid) => all[pid.toUpperCase()];
  static String getName(String pid) => get(pid)?.name ?? 'PID ${pid.toUpperCase()}';
  static String getUnit(String pid) => get(pid)?.unit ?? '';
  static List<String> get fastPids => all.values.where((p) => p.fast).map((p) => p.pid).toList();
}
