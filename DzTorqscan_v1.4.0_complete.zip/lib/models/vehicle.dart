class VehicleModel {
  final String id;
  final String brand;
  final String model;
  final String year;
  final String body;
  final String image;

  const VehicleModel({required this.id, required this.brand, required this.model, required this.year, required this.body, required this.image});
}

class VehicleCatalog {
  static const vehicles = <VehicleModel>[
    VehicleModel(id: 'peugeot_208', brand: 'Peugeot', model: '208', year: '2020–2026', body: 'Hatchback', image: 'assets/vehicles/peugeot_208.png'),
    VehicleModel(id: 'renault_clio', brand: 'Renault', model: 'Clio', year: '2019–2026', body: 'Hatchback', image: 'assets/vehicles/renault_clio.png'),
    VehicleModel(id: 'dacia_sandero', brand: 'Dacia', model: 'Sandero', year: '2021–2026', body: 'Hatchback', image: 'assets/vehicles/dacia_sandero.png'),
    VehicleModel(id: 'vw_golf', brand: 'Volkswagen', model: 'Golf', year: '2019–2026', body: 'Hatchback', image: 'assets/vehicles/vw_golf.png'),
    VehicleModel(id: 'toyota_corolla', brand: 'Toyota', model: 'Corolla', year: '2019–2026', body: 'Berline', image: 'assets/vehicles/toyota_corolla.png'),
    VehicleModel(id: 'mercedes_c', brand: 'Mercedes-Benz', model: 'Classe C', year: '2021–2026', body: 'Berline', image: 'assets/vehicles/mercedes_c.png'),
    VehicleModel(id: 'hyundai_tucson', brand: 'Hyundai', model: 'Tucson', year: '2021–2026', body: 'SUV', image: 'assets/vehicles/hyundai_tucson.png'),
    VehicleModel(id: 'generic_obd', brand: 'Autre', model: 'Véhicule OBD-II', year: '—', body: 'Générique', image: 'assets/vehicles/generic_obd.png'),
  ];

  static VehicleModel? byId(String? id) {
    for (final v in vehicles) {
      if (v.id == id) return v;
    }
    return null;
  }
}
