import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/app_settings.dart';
import '../models/vehicle.dart';

class VehicleSelectorScreen extends StatefulWidget {
  const VehicleSelectorScreen({super.key});
  @override State<VehicleSelectorScreen> createState() => _VehicleSelectorScreenState();
}

class _VehicleSelectorScreenState extends State<VehicleSelectorScreen> {
  String _query = '';
  String _brand = 'Toutes';
  VehicleModel? _selected;

  @override
  void initState() {
    super.initState();
    final id = context.read<AppSettings>().selectedVehicleId;
    _selected = VehicleCatalog.byId(id);
  }

  @override
  Widget build(BuildContext context) {
    final brands = ['Toutes', ...VehicleCatalog.vehicles.map((v) => v.brand).toSet()];
    final list = VehicleCatalog.vehicles.where((v) {
      final matchesBrand = _brand == 'Toutes' || v.brand == _brand;
      final q = _query.toLowerCase();
      return matchesBrand && ('${v.brand} ${v.model}'.toLowerCase().contains(q));
    }).toList();
    return Scaffold(
      appBar: AppBar(title: Text(tr(context, 'select_vehicle'))),
      body: Column(children: [
        Padding(padding: const EdgeInsets.fromLTRB(16, 12, 16, 8), child: TextField(decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Peugeot, Clio, Golf...'), onChanged: (v) => setState(() => _query = v))),
        SizedBox(height: 48, child: ListView.separated(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 16), itemCount: brands.length, separatorBuilder: (_, __) => const SizedBox(width: 8), itemBuilder: (_, i) => ChoiceChip(label: Text(brands[i]), selected: _brand == brands[i], onSelected: (_) => setState(() => _brand = brands[i])))),
        Expanded(child: GridView.builder(padding: const EdgeInsets.all(16), gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: .9), itemCount: list.length, itemBuilder: (_, i) => _vehicleCard(context, list[i]))),
      ]),
      bottomNavigationBar: SafeArea(child: Padding(padding: const EdgeInsets.all(16), child: FilledButton.icon(onPressed: _selected == null ? null : () { context.read<AppSettings>().setVehicle(_selected!.id); Navigator.pop(context, _selected); }, icon: const Icon(Icons.check), label: Text(tr(context, 'save'))))),
    );
  }

  Widget _vehicleCard(BuildContext context, VehicleModel v) {
    final selected = _selected?.id == v.id;
    return InkWell(onTap: () => setState(() => _selected = v), borderRadius: BorderRadius.circular(18), child: Card(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18), side: selected ? BorderSide(color: Theme.of(context).colorScheme.primary, width: 2) : BorderSide.none), clipBehavior: Clip.antiAlias, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Expanded(child: Container(color: Theme.of(context).colorScheme.surfaceContainerHighest, width: double.infinity, child: Image.asset(v.image, fit: BoxFit.contain))),
      Padding(padding: const EdgeInsets.fromLTRB(12, 10, 12, 12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${v.brand} ${v.model}', style: const TextStyle(fontWeight: FontWeight.bold)), const SizedBox(height: 3), Text('${v.year} • ${v.body}', style: Theme.of(context).textTheme.bodySmall)])),
    ])));
  }
}
