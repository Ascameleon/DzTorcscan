import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/app_settings.dart';
import '../services/obd_service.dart';

class VehicleInfoScreen extends StatelessWidget { const VehicleInfoScreen({super.key});
 @override Widget build(BuildContext context){return Scaffold(appBar:AppBar(title:Text(tr(context,'diagnostic'))),body:Consumer<OBDService>(builder:(context,obd,_){final caps=obd.capabilities;final supported=obd.supportedPids.toList()..sort();return ListView(padding:const EdgeInsets.all(16),children:[_section(context,tr(context,'connection'),[_row(context,tr(context,'protocol'),obd.protocol??'—'),_row(context,tr(context,'obd_standard'),caps.obdStandard??'—'),_row(context,tr(context,'supported_pids'),'${supported.length}')]),const SizedBox(height:14),_section(context,tr(context,'system_info'),[if(supported.isEmpty)Padding(padding:const EdgeInsets.all(12),child:Text(tr(context,'not_detected')))else Wrap(spacing:7,runSpacing:7,children:supported.map((p)=>Chip(label:Text(p))).toList())]),const SizedBox(height:14),Card(child:Padding(padding:const EdgeInsets.all(16),child:Text(tr(context,'reality'),style:TextStyle(color:Theme.of(context).colorScheme.onSurfaceVariant,height:1.45))))]);});}
 Widget _section(BuildContext c,String title,List<Widget> children)=>Card(child:Padding(padding:const EdgeInsets.fromLTRB(16,14,16,16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:const TextStyle(fontWeight:FontWeight.bold,fontSize:16)),const SizedBox(height:10),...children])));
 Widget _row(BuildContext c,String label,String value)=>Padding(padding:const EdgeInsets.symmetric(vertical:6),child:Row(children:[Expanded(child:Text(label,style:TextStyle(color:Theme.of(c).colorScheme.onSurfaceVariant)),),Flexible(child:Text(value,textAlign:TextAlign.right))]));
}
