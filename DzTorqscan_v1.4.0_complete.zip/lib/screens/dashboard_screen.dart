import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/app_settings.dart';
import '../services/bluetooth_service.dart';
import '../services/obd_service.dart';
import '../models/pid_data.dart';
import 'dtc_screen.dart';
import 'home_screen.dart';
import 'vehicle_info_screen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _start());
  }

  Future<void> _start() async {
    final settings = context.read<AppSettings>();
    final obd = context.read<OBDService>();
    if (obd.isDemo) {
      await obd.startLiveScan(options: settings.scanOptions);
      return;
    }
    if (settings.scanOptions.confirmedDtc) await obd.readDTCs();
    if (settings.scanOptions.pendingDtc) await obd.readPendingDTCs();
    await obd.startLiveScan(options: settings.scanOptions);
  }

  Future<void> _disconnect() async {
    final obd = context.read<OBDService>();
    final bt = context.read<BluetoothService>();
    obd.stopLiveScan();
    obd.stopDemo();
    await bt.disconnect();
    if (mounted) {
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const HomeScreen()),
        (_) => false,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
        title: Text(tr(context, 'app_name')),
        leading: IconButton(
          icon: const Icon(Icons.power_settings_new),
          tooltip: tr(context, 'disconnect'),
          onPressed: _disconnect,
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.memory_outlined),
            tooltip: tr(context, 'diagnostic'),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const VehicleInfoScreen()),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.warning_amber_rounded),
            tooltip: tr(context, 'fault_codes'),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const DTCScreen()),
            ).then((_) {
              if (mounted) _start();
            }),
          ),
        ],
      ),
      body: Consumer2<OBDService, BluetoothService>(
        builder: (context, obd, bt, _) {
          final connected = bt.isConnected || obd.isDemo;
          if (!connected) {
            return Center(child: Text(tr(context, 'disconnect')));
          }

          final data = obd.liveData;
          final rpm = data['010C'];
          final speed = data['010D'];

          return Column(
            children: [
              // Status bar
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                color: scheme.surfaceContainerHighest.withOpacity(0.5),
                child: Row(
                  children: [
                    Container(
                      width: 10,
                      height: 10,
                      decoration: BoxDecoration(
                        color: obd.isScanning ? scheme.primary : Colors.orange,
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        obd.isDemo
                            ? '${tr(context, 'demo_mode')} • ${bt.connectionLabel}'
                            : bt.connectionLabel,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    if (obd.protocol != null)
                      Padding(
                        padding: const EdgeInsets.only(right: 8),
                        child: Text(
                          obd.protocol!,
                          style: TextStyle(fontSize: 12, color: scheme.onSurfaceVariant),
                        ),
                      ),
                    Text(
                      obd.isScanning ? tr(context, 'live') : tr(context, 'pause'),
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: obd.isScanning ? scheme.primary : Colors.orange,
                      ),
                    ),
                  ],
                ),
              ),

              if (obd.lastError != null)
                MaterialBanner(
                  content: Text(obd.lastError!),
                  leading: const Icon(Icons.error_outline),
                  actions: [
                    TextButton(onPressed: _start, child: Text(tr(context, 'retry'))),
                  ],
                ),

              // Hero gauges: RPM + Speed
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 12, 12, 0),
                child: Row(
                  children: [
                    Expanded(child: _heroGauge(
                      context,
                      title: tr(context, 'rpm'),
                      value: rpm?.displayValue ?? '—',
                      unit: rpm?.unit ?? 'tr/min',
                      icon: Icons.speed,
                      accent: scheme.primary,
                    )),
                    const SizedBox(width: 12),
                    Expanded(child: _heroGauge(
                      context,
                      title: tr(context, 'speed'),
                      value: speed?.displayValue ?? '—',
                      unit: speed?.unit ?? 'km/h',
                      icon: Icons.directions_car,
                      accent: scheme.tertiary,
                    )),
                  ],
                ),
              ),

              // Secondary PIDs grid
              Expanded(
                child: GridView.count(
                  padding: const EdgeInsets.all(12),
                  crossAxisCount: 2,
                  mainAxisSpacing: 12,
                  crossAxisSpacing: 12,
                  childAspectRatio: 1.35,
                  children: [
                    _pidCard(context, tr(context, 'coolant'), '0105', data['0105'], Icons.thermostat),
                    _pidCard(context, tr(context, 'load'), '0104', data['0104'], Icons.donut_large),
                    _pidCard(context, tr(context, 'throttle'), '0111', data['0111'], Icons.swipe_up),
                    _pidCard(context, tr(context, 'voltage'), '0142', data['0142'], Icons.battery_charging_full),
                    _pidCard(context, tr(context, 'map'), '010B', data['010B'], Icons.compress),
                    _pidCard(context, tr(context, 'fuel'), '012F', data['012F'], Icons.local_gas_station),
                    _pidCard(context, tr(context, 'iat'), '010F', data['010F'], Icons.air),
                    _pidCard(context, tr(context, 'timing'), '010E', data['010E'], Icons.timelapse),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _heroGauge(
    BuildContext context, {
    required String title,
    required String value,
    required String unit,
    required IconData icon,
    required Color accent,
  }) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, size: 18, color: accent),
                const SizedBox(width: 8),
                Text(title, style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
              ],
            ),
            const SizedBox(height: 10),
            Text(
              value,
              style: TextStyle(fontSize: 36, fontWeight: FontWeight.w800, color: accent, height: 1),
            ),
            const SizedBox(height: 4),
            Text(unit, style: TextStyle(fontSize: 13, color: Theme.of(context).colorScheme.onSurfaceVariant)),
          ],
        ),
      ),
    );
  }

  Widget _pidCard(BuildContext context, String title, String pid, PIDData? data, IconData icon) {
    final accent = data?.available == false
        ? Theme.of(context).colorScheme.outline
        : Theme.of(context).colorScheme.primary;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, size: 17, color: accent),
                const SizedBox(width: 7),
                Expanded(
                  child: Text(
                    title,
                    style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant, fontSize: 13),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
            const Spacer(),
            Text(
              data?.displayValue ?? '—',
              style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: accent),
            ),
            const SizedBox(height: 2),
            Text(
              data?.unit ?? PIDDefinitions.getUnit(pid),
              style: TextStyle(fontSize: 11, color: Theme.of(context).colorScheme.onSurfaceVariant),
            ),
          ],
        ),
      ),
    );
  }
}
