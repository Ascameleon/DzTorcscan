import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/app_settings.dart';
import '../services/obd_service.dart';
import '../models/pid_data.dart';

class DTCScreen extends StatefulWidget {
  const DTCScreen({super.key});

  @override
  State<DTCScreen> createState() => _DTCScreenState();
}

class _DTCScreenState extends State<DTCScreen> {
  bool loading = false;
  bool clearing = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  Future<void> _load() async {
    if (!mounted) return;
    setState(() => loading = true);
    final obd = context.read<OBDService>();
    final settings = context.read<AppSettings>();
    if (settings.scanOptions.confirmedDtc) await obd.readDTCs();
    if (settings.scanOptions.pendingDtc) await obd.readPendingDTCs();
    if (mounted) setState(() => loading = false);
  }

  Future<void> _clear() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(tr(dialogContext, 'clear_confirm')),
        content: Text(tr(dialogContext, 'clear_warning')),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: Text(tr(dialogContext, 'cancel')),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: Text(tr(dialogContext, 'clear')),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;

    setState(() => clearing = true);
    final success = await context.read<OBDService>().clearDTCs();
    if (!mounted) return;
    setState(() => clearing = false);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(tr(context, success ? 'clear_success' : 'clear_failed'))),
    );
    if (success) await _load();
  }

  @override
  Widget build(BuildContext context) {
    final scanOptions = context.watch<AppSettings>().scanOptions;
    final dtcScanDisabled = !scanOptions.confirmedDtc && !scanOptions.pendingDtc;
    return Scaffold(
      appBar: AppBar(
        title: Text(tr(context, 'fault_codes')),
        actions: [
          IconButton(
            onPressed: loading ? null : _load,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: Consumer<OBDService>(
        builder: (context, obd, _) {
          if (loading) return const Center(child: CircularProgressIndicator());
          if (dtcScanDisabled) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.info_outline, size: 72, color: Theme.of(context).colorScheme.primary),
                    const SizedBox(height: 18),
                    Text(
                      tr(context, 'dtc_scan_disabled'),
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      tr(context, 'dtc_scan_disabled_desc'),
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant),
                    ),
                  ],
                ),
              ),
            );
          }
          final confirmedCodes = obd.dtcCodes;
          final pendingCodes = obd.pendingDtcCodes;
          final readError = obd.isInitialized ? obd.dtcReadError : tr(context, 'obd_not_ready');

          if (confirmedCodes.isEmpty && pendingCodes.isEmpty) {
            final hasError = readError != null;
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      hasError ? Icons.error_outline : Icons.check_circle_outline,
                      size: 76,
                      color: hasError
                          ? Theme.of(context).colorScheme.error
                          : Theme.of(context).colorScheme.primary,
                    ),
                    const SizedBox(height: 20),
                    Text(
                      tr(context, hasError ? 'read_failed' : 'no_fault'),
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      readError ?? tr(context, 'no_fault_desc'),
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant),
                    ),
                    if (hasError) ...[
                      const SizedBox(height: 16),
                      FilledButton.icon(
                        onPressed: loading ? null : _load,
                        icon: const Icon(Icons.refresh),
                        label: Text(tr(context, 'retry')),
                      ),
                    ],
                  ],
                ),
              ),
            );
          }

          return Column(
            children: [
              if (readError != null)
                MaterialBanner(
                  content: Text(readError),
                  leading: const Icon(Icons.error_outline),
                  actions: [
                    TextButton(onPressed: _load, child: Text(tr(context, 'retry'))),
                  ],
                ),
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.all(12),
                  children: [
                    if (confirmedCodes.isNotEmpty) ...[
                      _header(tr(context, 'confirmed'), confirmedCodes.length, Colors.red),
                      ...confirmedCodes.map((code) => _card(code, false)),
                    ],
                    if (pendingCodes.isNotEmpty) ...[
                      const SizedBox(height: 12),
                      _header(tr(context, 'pending'), pendingCodes.length, Colors.orange),
                      ...pendingCodes.map((code) => _card(code, true)),
                    ],
                  ],
                ),
              ),
              SafeArea(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: clearing ? null : _clear,
                      icon: clearing
                          ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                          : const Icon(Icons.delete_forever),
                      label: Text(tr(context, 'clear_codes')),
                    ),
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _header(String title, int count, Color color) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 8, 4, 10),
        child: Row(
          children: [
            Container(
              width: 4,
              height: 18,
              decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(3)),
            ),
            const SizedBox(width: 10),
            Text(title, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(color: color.withOpacity(.15), borderRadius: BorderRadius.circular(10)),
              child: Text('$count', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: color)),
            ),
          ],
        ),
      );

  Widget _card(DTCCode dtc, bool pending) => Card(
        margin: const EdgeInsets.only(bottom: 10),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  color: (pending ? Colors.orange : Colors.red).withOpacity(.12),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Center(
                  child: Text(
                    dtc.code.substring(0, 1),
                    style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold, color: pending ? Colors.orange : Colors.red),
                  ),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(dtc.code, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 5),
                    Text(
                      dtc.description,
                      style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant, height: 1.35),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      );
}
