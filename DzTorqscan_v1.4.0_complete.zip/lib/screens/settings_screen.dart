import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/app_settings.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<AppSettings>();
    return Scaffold(
      appBar: AppBar(title: Text(tr(context, 'advanced_title'))),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _section(context, tr(context, 'language'), [
            SegmentedButton<String>(
              segments: const [
                ButtonSegment(value: 'fr', label: Text('Français'), icon: Icon(Icons.language)),
                ButtonSegment(value: 'en', label: Text('English')),
                ButtonSegment(value: 'ar', label: Text('العربية')),
              ], selected: {settings.language}, onSelectionChanged: (s) => settings.setLanguage(s.first),
            ),
          ]),
          const SizedBox(height: 14),
          _section(context, tr(context, 'theme'), [
            SegmentedButton<ThemeMode>(
              segments: [
                ButtonSegment(value: ThemeMode.light, label: Text(tr(context, 'light')), icon: const Icon(Icons.light_mode)),
                ButtonSegment(value: ThemeMode.dark, label: Text(tr(context, 'dark')), icon: const Icon(Icons.dark_mode)),
                ButtonSegment(value: ThemeMode.system, label: Text(tr(context, 'system')), icon: const Icon(Icons.brightness_auto)),
              ], selected: {settings.themeMode}, onSelectionChanged: (s) => settings.setTheme(s.first),
            ),
          ]),
          const SizedBox(height: 14),
          _section(context, tr(context, 'advanced_title'), [
            SwitchListTile.adaptive(title: Text(tr(context, 'live_data')), value: settings.scanOptions.liveData, onChanged: (v) => settings.setScanOptions(settings.scanOptions.copyWith(liveData: v))),
            SwitchListTile.adaptive(title: Text(tr(context, 'confirmed_dtc')), value: settings.scanOptions.confirmedDtc, onChanged: (v) => settings.setScanOptions(settings.scanOptions.copyWith(confirmedDtc: v))),
            SwitchListTile.adaptive(title: Text(tr(context, 'pending_dtc')), value: settings.scanOptions.pendingDtc, onChanged: (v) => settings.setScanOptions(settings.scanOptions.copyWith(pendingDtc: v))),
            SwitchListTile.adaptive(title: Text(tr(context, 'full_pid')), subtitle: Text(tr(context, 'full_pid_desc')), value: settings.scanOptions.fullPidScan, onChanged: (v) => settings.setScanOptions(settings.scanOptions.copyWith(fullPidScan: v))),
            const SizedBox(height: 8),
            Text(tr(context, 'refresh_rate'), style: Theme.of(context).textTheme.titleSmall),
            SegmentedButton<int>(
              segments: [
                ButtonSegment(value: 75, label: Text(tr(context, 'fast'))),
                ButtonSegment(value: 150, label: Text(tr(context, 'balanced'))),
                ButtonSegment(value: 300, label: Text(tr(context, 'safe'))),
              ], selected: {settings.scanOptions.liveRefreshMs}, onSelectionChanged: (s) => settings.setScanOptions(settings.scanOptions.copyWith(liveRefreshMs: s.first)),
            ),
          ]),
        ],
      ),
    );
  }

  Widget _section(BuildContext context, String title, List<Widget> children) => Card(
        child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)), const SizedBox(height: 12), ...children])),
      );
}
