import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'core/app_settings.dart';
import 'services/bluetooth_service.dart';
import 'services/obd_service.dart';
import 'screens/home_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations(const [DeviceOrientation.portraitUp, DeviceOrientation.portraitDown]);
  runApp(ChangeNotifierProvider(create: (_) => AppSettings(), child: const TorqScanApp()));
}

class TorqScanApp extends StatelessWidget {
  const TorqScanApp({super.key});

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<AppSettings>();
    final lightScheme = ColorScheme.fromSeed(seedColor: const Color(0xFF1B8A67), brightness: Brightness.light);
    final darkScheme = ColorScheme.fromSeed(seedColor: const Color(0xFF1B8A67), brightness: Brightness.dark);
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => BluetoothService()),
        ChangeNotifierProxyProvider<BluetoothService, OBDService>(
          create: (context) => OBDService(context.read<BluetoothService>()),
          update: (context, bluetooth, previous) => previous ?? OBDService(bluetooth),
        ),
      ],
      child: MaterialApp(
        title: 'Dz Torqscan',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(useMaterial3: true, brightness: Brightness.light, colorScheme: lightScheme, scaffoldBackgroundColor: const Color(0xFFF7F8F7), appBarTheme: const AppBarTheme(centerTitle: false, surfaceTintColor: Colors.transparent), cardTheme: CardThemeData(elevation: 0, margin: EdgeInsets.zero, shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(18)))), inputDecorationTheme: const InputDecorationTheme(filled: true, border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(14)), borderSide: BorderSide.none))),
        darkTheme: ThemeData(useMaterial3: true, brightness: Brightness.dark, colorScheme: darkScheme, scaffoldBackgroundColor: const Color(0xFF101210), cardTheme: CardThemeData(elevation: 0, margin: EdgeInsets.zero, shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(18)))), inputDecorationTheme: const InputDecorationTheme(filled: true, border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(14)), borderSide: BorderSide.none))),
        themeMode: settings.themeMode,
        locale: Locale(settings.language),
        builder: (context, child) => Directionality(textDirection: settings.isArabic ? TextDirection.rtl : TextDirection.ltr, child: child!),
        home: const HomeScreen(),
      ),
    );
  }
}
