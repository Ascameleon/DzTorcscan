import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class ScanOptions {
  final bool liveData;
  final bool confirmedDtc;
  final bool pendingDtc;
  final bool fullPidScan;
  final int liveRefreshMs;

  const ScanOptions({
    this.liveData = true,
    this.confirmedDtc = true,
    this.pendingDtc = true,
    this.fullPidScan = false,
    this.liveRefreshMs = 150,
  });

  ScanOptions copyWith({
    bool? liveData,
    bool? confirmedDtc,
    bool? pendingDtc,
    bool? fullPidScan,
    int? liveRefreshMs,
  }) => ScanOptions(
        liveData: liveData ?? this.liveData,
        confirmedDtc: confirmedDtc ?? this.confirmedDtc,
        pendingDtc: pendingDtc ?? this.pendingDtc,
        fullPidScan: fullPidScan ?? this.fullPidScan,
        liveRefreshMs: liveRefreshMs ?? this.liveRefreshMs,
      );
}

class AppSettings extends ChangeNotifier {
  String language = 'fr';
  ThemeMode themeMode = ThemeMode.light;
  ScanOptions scanOptions = const ScanOptions();
  String? selectedVehicleId;

  bool get isArabic => language == 'ar';

  void setLanguage(String value) {
    if (!['fr', 'en', 'ar'].contains(value)) return;
    language = value;
    notifyListeners();
  }

  void setTheme(ThemeMode value) {
    themeMode = value;
    notifyListeners();
  }

  void setScanOptions(ScanOptions value) {
    scanOptions = value;
    notifyListeners();
  }

  void setVehicle(String? id) {
    selectedVehicleId = id;
    notifyListeners();
  }
}

class AppStrings {
  static const Map<String, Map<String, String>> _data = {
    'fr': {
      'app_name': 'Dz Torqscan', 'scan': 'Scanner', 'vehicles': 'Véhicule', 'advanced': 'Scan avancé',
      'language': 'Langue', 'theme': 'Thème', 'light': 'Clair', 'dark': 'Sombre', 'system': 'Système',
      'connected': 'Connecté', 'connect': 'Connexion', 'refresh': 'Actualiser', 'paired': 'Appareils appairés',
      'connection_mode': 'Mode de connexion', 'bluetooth': 'Bluetooth', 'wifi_tcp': 'Wi-Fi TCP', 'wifi_host': 'Adresse IP de l’adaptateur', 'wifi_port': 'Port TCP', 'connect_wifi': 'Connecter en Wi-Fi', 'wifi_hint': 'Connectez le téléphone au réseau Wi-Fi de l’adaptateur OBD2. Valeurs courantes : 192.168.0.10, port 35000.',
      'no_devices': 'Aucun appareil appairé trouvé', 'bluetooth_help': 'Activez le Bluetooth et appairez votre adaptateur OBD2 dans les réglages du téléphone.',
      'select_vehicle': 'Choisir le véhicule', 'selected_vehicle': 'Véhicule sélectionné', 'change': 'Modifier',
      'choose_model': 'Choisissez la marque et le modèle à scanner', 'brand': 'Marque', 'model': 'Modèle',
      'year': 'Année', 'body': 'Carrosserie', 'save': 'Enregistrer', 'cancel': 'Annuler', 'continue': 'Continuer',
      'advanced_title': 'Options de scan avancé', 'live_data': 'Données temps réel', 'confirmed_dtc': 'Codes défaut confirmés',
      'pending_dtc': 'Codes défaut en attente', 'full_pid': 'Scan complet des PIDs supportés', 'full_pid_desc': 'Interroge les PIDs disponibles avant le suivi temps réel.',
      'refresh_rate': 'Fréquence temps réel', 'fast': 'Rapide', 'balanced': 'Équilibré', 'safe': 'Économique',
      'start_scan': 'Démarrer le scan', 'connection': 'Connexion', 'diagnostic': 'Diagnostic système', 'fault_codes': 'Codes défauts',
      'disconnect': 'Déconnecter', 'live': 'LIVE', 'pause': 'PAUSE', 'rpm': 'Régime', 'speed': 'Vitesse',
      'coolant': 'Temp. eau', 'load': 'Charge', 'throttle': 'Accélérateur', 'voltage': 'Tension', 'map': 'Pression MAP',
      'fuel': 'Carburant', 'no_fault': 'Aucun code défaut', 'no_fault_desc': 'Le calculateur ne signale aucun problème',
      'confirmed': 'Codes confirmés', 'pending': 'Codes en attente', 'clear_codes': 'Effacer les codes',
      'system_info': 'Informations système', 'protocol': 'Protocole', 'obd_standard': 'Standard OBD', 'supported_pids': 'PIDs supportés',
      'not_available': 'N/D', 'not_detected': 'Aucun PID détecté.', 'reality': 'Dz Torqscan affiche uniquement les valeurs réellement reçues de l’ECU.',
      'connecting': 'Connexion en cours...', 'ignition': 'Mettez le contact de la voiture', 'tip': 'Choisissez l’appareil contenant OBD, ELM, V-LINK ou OBDII.',
      'clear_confirm': 'Effacer les codes défaut ?', 'clear_warning': 'Cette action efface les codes stockés dans le calculateur. Continuer ?',
      'clear': 'Effacer', 'error': 'Erreur', 'retry': 'Réessayer', 'demo_mode': 'Mode démo', 'demo_start': 'Essayer en mode démo', 'iat': 'Air admission', 'timing': 'Avance allumage', 'read_failed': 'Lecture impossible', 'dtc_scan_disabled': 'Lecture des défauts désactivée', 'dtc_scan_disabled_desc': 'Activez les codes confirmés ou en attente dans les options de scan avancé pour vérifier les défauts du véhicule.', 'obd_not_ready': 'Connexion OBD indisponible. Reconnectez l’adaptateur.', 'clear_success': 'Codes effacés', 'clear_failed': 'Échec de l’effacement',
    },
    'en': {
      'app_name': 'Dz Torqscan', 'scan': 'Scan', 'vehicles': 'Vehicle', 'advanced': 'Advanced scan',
      'language': 'Language', 'theme': 'Theme', 'light': 'Light', 'dark': 'Dark', 'system': 'System',
      'connected': 'Connected', 'connect': 'Connect', 'refresh': 'Refresh', 'paired': 'Paired devices',
      'connection_mode': 'Connection mode', 'bluetooth': 'Bluetooth', 'wifi_tcp': 'Wi-Fi TCP', 'wifi_host': 'Adapter IP address', 'wifi_port': 'TCP port', 'connect_wifi': 'Connect over Wi-Fi', 'wifi_hint': 'Connect your phone to the OBD2 adapter Wi-Fi network. Common values: 192.168.0.10, port 35000.',
      'no_devices': 'No paired device found', 'bluetooth_help': 'Enable Bluetooth and pair your OBD2 adapter in the phone settings.',
      'select_vehicle': 'Choose vehicle', 'selected_vehicle': 'Selected vehicle', 'change': 'Change',
      'choose_model': 'Choose the make and model to scan', 'brand': 'Make', 'model': 'Model',
      'year': 'Year', 'body': 'Body', 'save': 'Save', 'cancel': 'Cancel', 'continue': 'Continue',
      'advanced_title': 'Advanced scan options', 'live_data': 'Live data', 'confirmed_dtc': 'Confirmed trouble codes',
      'pending_dtc': 'Pending trouble codes', 'full_pid': 'Full supported PID scan', 'full_pid_desc': 'Queries available PIDs before live monitoring.',
      'refresh_rate': 'Live refresh rate', 'fast': 'Fast', 'balanced': 'Balanced', 'safe': 'Economy',
      'start_scan': 'Start scan', 'connection': 'Connection', 'diagnostic': 'System diagnostic', 'fault_codes': 'Trouble codes',
      'disconnect': 'Disconnect', 'live': 'LIVE', 'pause': 'PAUSE', 'rpm': 'RPM', 'speed': 'Speed',
      'coolant': 'Coolant temp.', 'load': 'Load', 'throttle': 'Throttle', 'voltage': 'Voltage', 'map': 'MAP pressure',
      'fuel': 'Fuel', 'no_fault': 'No trouble codes', 'no_fault_desc': 'The ECU reports no fault codes',
      'confirmed': 'Confirmed codes', 'pending': 'Pending codes', 'clear_codes': 'Clear codes',
      'system_info': 'System information', 'protocol': 'Protocol', 'obd_standard': 'OBD standard', 'supported_pids': 'Supported PIDs',
      'not_available': 'N/A', 'not_detected': 'No PID detected.', 'reality': 'Dz Torqscan displays only values actually received from the ECU.',
      'connecting': 'Connecting...', 'ignition': 'Turn the vehicle ignition on', 'tip': 'Choose the device containing OBD, ELM, V-LINK or OBDII.',
      'clear_confirm': 'Clear trouble codes?', 'clear_warning': 'This clears stored codes from the ECU. Continue?',
      'clear': 'Clear', 'error': 'Error', 'retry': 'Retry', 'demo_mode': 'Demo mode', 'demo_start': 'Try demo mode', 'iat': 'Intake air', 'timing': 'Timing advance', 'read_failed': 'Reading failed', 'dtc_scan_disabled': 'Trouble-code scan disabled', 'dtc_scan_disabled_desc': 'Enable confirmed or pending trouble codes in Advanced Scan settings to check the vehicle for faults.', 'obd_not_ready': 'OBD connection unavailable. Reconnect the adapter.', 'clear_success': 'Codes cleared', 'clear_failed': 'Clear failed',
    },
    'ar': {
      'app_name': 'Dz Torqscan', 'scan': 'فحص', 'vehicles': 'المركبة', 'advanced': 'فحص متقدم',
      'language': 'اللغة', 'theme': 'المظهر', 'light': 'فاتح', 'dark': 'داكن', 'system': 'النظام',
      'connected': 'متصل', 'connect': 'اتصال', 'refresh': 'تحديث', 'paired': 'الأجهزة المقترنة',
      'connection_mode': 'طريقة الاتصال', 'bluetooth': 'بلوتوث', 'wifi_tcp': 'واي فاي TCP', 'wifi_host': 'عنوان IP للمحول', 'wifi_port': 'منفذ TCP', 'connect_wifi': 'الاتصال عبر Wi-Fi', 'wifi_hint': 'صِل الهاتف بشبكة محول OBD2. القيم الشائعة: 192.168.0.10 والمنفذ 35000.',
      'no_devices': 'لم يتم العثور على جهاز مقترن', 'bluetooth_help': 'فعّل البلوتوث وقم بإقران محول OBD2 من إعدادات الهاتف.',
      'select_vehicle': 'اختيار المركبة', 'selected_vehicle': 'المركبة المختارة', 'change': 'تغيير',
      'choose_model': 'اختر العلامة والطراز للفحص', 'brand': 'العلامة', 'model': 'الطراز',
      'year': 'السنة', 'body': 'الهيكل', 'save': 'حفظ', 'cancel': 'إلغاء', 'continue': 'متابعة',
      'advanced_title': 'خيارات الفحص المتقدم', 'live_data': 'بيانات مباشرة', 'confirmed_dtc': 'أكواد الأعطال المؤكدة',
      'pending_dtc': 'أكواد الأعطال المعلقة', 'full_pid': 'فحص كامل للـ PID المدعومة', 'full_pid_desc': 'يفحص الـ PID المتاحة قبل المراقبة المباشرة.',
      'refresh_rate': 'معدل تحديث البيانات', 'fast': 'سريع', 'balanced': 'متوازن', 'safe': 'اقتصادي',
      'start_scan': 'بدء الفحص', 'connection': 'الاتصال', 'diagnostic': 'تشخيص النظام', 'fault_codes': 'أكواد الأعطال',
      'disconnect': 'قطع الاتصال', 'live': 'مباشر', 'pause': 'إيقاف', 'rpm': 'دورة المحرك', 'speed': 'السرعة',
      'coolant': 'حرارة الماء', 'load': 'الحمل', 'throttle': 'الخانق', 'voltage': 'الجهد', 'map': 'ضغط MAP',
      'fuel': 'الوقود', 'no_fault': 'لا توجد أكواد أعطال', 'no_fault_desc': 'وحدة التحكم لا تبلغ عن أعطال',
      'confirmed': 'أكواد مؤكدة', 'pending': 'أكواد معلقة', 'clear_codes': 'مسح الأكواد',
      'system_info': 'معلومات النظام', 'protocol': 'البروتوكول', 'obd_standard': 'معيار OBD', 'supported_pids': 'PID المدعومة',
      'not_available': 'غير متاح', 'not_detected': 'لم يتم اكتشاف PID.', 'reality': 'يعرض Dz Torqscan القيم التي تصل فعلياً من وحدة التحكم فقط.',
      'connecting': 'جارٍ الاتصال...', 'ignition': 'شغّل مفتاح السيارة', 'tip': 'اختر الجهاز الذي يحتوي على OBD أو ELM أو V-LINK أو OBDII.',
      'clear_confirm': 'مسح أكواد الأعطال؟', 'clear_warning': 'سيؤدي ذلك إلى مسح الأكواد المخزنة في وحدة التحكم. متابعة؟',
      'clear': 'مسح', 'error': 'خطأ', 'retry': 'إعادة المحاولة', 'demo_mode': 'وضع التجربة', 'demo_start': 'تجربة الوضع التجريبي', 'iat': 'هواء السحب', 'timing': 'تقدم الإشعال', 'read_failed': 'تعذرت القراءة', 'dtc_scan_disabled': 'فحص الأعطال معطّل', 'dtc_scan_disabled_desc': 'فعّل الأكواد المؤكدة أو المعلّقة في إعدادات الفحص المتقدم للتحقق من أعطال المركبة.', 'obd_not_ready': 'اتصال OBD غير متاح. أعد توصيل المحول.', 'clear_success': 'تم مسح الأكواد', 'clear_failed': 'فشل مسح الأكواد',
    },
  };

  static String t(String key, String language) => _data[language]?[key] ?? _data['en']![key] ?? key;
}

String tr(BuildContext context, String key) => AppStrings.t(key, context.read<AppSettings>().language);
