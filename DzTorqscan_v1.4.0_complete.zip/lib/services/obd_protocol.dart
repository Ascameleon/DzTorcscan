class ObdProtocol {
  static String normalize(String input) => input
      .toUpperCase()
      .replaceAll(RegExp(r'\s+'), '')
      .replaceAll('SEARCHING...', '')
      .replaceAll('SEARCHING..', '')
      .replaceAll('SEARCHING.', '');

  static bool isNegative(String response) {
    final n = normalize(response);
    return n.contains('NODATA') ||
        n.contains('UNABLETOCONNECT') ||
        n.contains('ERROR') ||
        n.contains('STOPPED') ||
        n.contains('?');
  }

  // NO DATA is a normal result for an empty DTC response; transport and
  // adapter errors must not be presented to the driver as 'no faults'.
  static bool isFailure(String response) {
    final n = normalize(response);
    return n.contains('UNABLETOCONNECT') ||
        n.contains('ERROR') ||
        n.contains('STOPPED') ||
        n.contains('CANERROR') ||
        n.contains('BUSINIT') ||
        n.contains('?');
  }

  static List<int> hexBytes(String text) {
    final n = normalize(text).replaceAll(RegExp(r'[^0-9A-F]'), '');
    final result = <int>[];
    for (var i = 0; i + 1 < n.length; i += 2) {
      result.add(int.tryParse(n.substring(i, i + 2), radix: 16) ?? -1);
    }
    return result.where((b) => b >= 0).toList();
  }

  static List<int> findPidData(String response, String pid, {int? length}) {
    final service = pid.substring(0, 2);
    final id = pid.substring(2);
    final positiveService = (int.parse(service, radix: 16) + 0x40)
        .toRadixString(16)
        .padLeft(2, '0')
        .toUpperCase();
    final header = '$positiveService$id'.toUpperCase();

    // ELM327 may return one line per ECU. Never flatten all lines before
    // extracting a PID: doing so can consume the next ECU's service byte as
    // payload (for example, 41 0C 1A followed by 41 0C 1B).
    for (final line in response.split(RegExp(r'[\r\n]+'))) {
      final normalized = normalize(line);
      final index = normalized.indexOf(header);
      if (index < 0) continue;
      final bytes = hexBytes(normalized.substring(index + header.length));
      if (bytes.isEmpty) continue;
      if (length == null) return bytes;
      if (bytes.length >= length) return bytes.take(length).toList();
    }
    return const [];
  }

  static Set<String> decodeSupportedPids(String response, int basePid) {
    final request = basePid.toRadixString(16).padLeft(4, '0').toUpperCase();
    final result = <String>{};
    // Multiple ECUs can report different supported PID masks. Union the masks
    // from each response line instead of silently trusting only the first ECU.
    for (final line in response.split(RegExp(r'[\r\n]+'))) {
      final bytes = findPidData(line, request);
      if (bytes.length < 4) continue;
      for (var byteIndex = 0; byteIndex < 4; byteIndex++) {
        final byte = bytes[byteIndex];
        for (var bit = 0; bit < 8; bit++) {
          if ((byte & (1 << (7 - bit))) != 0) {
            final pidNumber = basePid + byteIndex * 8 + bit + 1;
            if (pidNumber <= basePid + 0x20) {
              final lowByte = pidNumber & 0xFF;
              result.add('01${lowByte.toRadixString(16).padLeft(2, '0').toUpperCase()}');
            }
          }
        }
      }
    }
    return result;
  }

  static String? decodeDtcWord(int word) {
    if (word == 0) return null;
    final type = (word >> 14) & 0x03;
    final d1 = (word >> 12) & 0x03;
    final d2 = (word >> 8) & 0x0F;
    final d3 = (word >> 4) & 0x0F;
    final d4 = word & 0x0F;
    const prefixes = ['P', 'C', 'B', 'U'];
    return '${prefixes[type]}$d1${d2.toRadixString(16).toUpperCase()}${d3.toRadixString(16).toUpperCase()}${d4.toRadixString(16).toUpperCase()}';
  }

  static List<String> parseDtc(String response, int positiveService) {
    // A multi-ECU adapter response may contain NO DATA for one ECU and valid
    // DTC frames from another. Decide from actual positive-service frames,
    // not from a negative marker anywhere in the combined response.
    final header = (positiveService + 0x40)
        .toRadixString(16)
        .padLeft(2, '0')
        .toUpperCase();
    final codes = <String>[];

    // Keep line boundaries: some ELM327 adapters return one response line
    // per ECU. Flattening the whole response first can treat the next line's
    // service byte as if it were part of the previous ECU's DTC payload.
    for (final line in response.split(RegExp(r'[\r\n]+'))) {
      final normalized = normalize(line);
      final start = normalized.indexOf(header);
      if (start < 0) continue;
      final bytes = hexBytes(normalized.substring(start + header.length));
      for (var i = 0; i + 1 < bytes.length; i += 2) {
        final code = decodeDtcWord((bytes[i] << 8) | bytes[i + 1]);
        if (code != null && !codes.contains(code)) codes.add(code);
      }
    }
    return codes;
  }
}
