import 'dart:io';

/// Validated TCP endpoint for Wi-Fi ELM327 adapters.
/// Accepts IPv4/IPv6 literals and ordinary DNS hostnames, never URL paths.
class ConnectionEndpoint {
  final String host;
  final int port;

  const ConnectionEndpoint._(this.host, this.port);

  static ConnectionEndpoint parse(String rawHost, int port) {
    var host = rawHost.trim();
    final bracketed = host.startsWith('[') || host.endsWith(']');
    if (bracketed) {
      // Brackets are URI notation for IPv6 literals only. Do not silently
      // accept bracketed DNS names or malformed/mismatched bracket pairs.
      if (!(host.startsWith('[') && host.endsWith(']'))) {
        throw const FormatException('Notation IPv6 entre crochets invalide.');
      }
      host = host.substring(1, host.length - 1);
      final bracketLiteral = InternetAddress.tryParse(host);
      if (bracketLiteral == null || bracketLiteral.type != InternetAddressType.IPv6) {
        throw const FormatException('Les crochets sont réservés aux adresses IPv6.');
      }
    }
    if (host.isEmpty || host.length > 253) {
      throw const FormatException('Adresse de l’adaptateur invalide.');
    }
    if (port < 1 || port > 65535) {
      throw const FormatException('Le port TCP doit être compris entre 1 et 65535.');
    }

    final literal = InternetAddress.tryParse(host);
    if (literal == null) {
      // A dotted numeric address that failed IP parsing is a malformed IPv4,
      // not a hostname.
      if (RegExp(r'^[0-9.]+$').hasMatch(host)) {
        throw const FormatException('Adresse IPv4 invalide.');
      }
      // Prevent URL schemes, paths, whitespace and malformed DNS labels.
      // Fully-qualified DNS names may legally end with one root dot
      // (for example, obd-adapter.local.). Validate the labels without that
      // final dot while preserving the user's host for Socket.connect.
      final dnsName = host.endsWith('.') ? host.substring(0, host.length - 1) : host;
      final validHostname = dnsName.isNotEmpty && dnsName.split('.').every((label) =>
          label.isNotEmpty &&
          label.length <= 63 &&
          RegExp(r'^[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?$').hasMatch(label));
      if (!validHostname || host.contains(':') || host.contains('/') || host.contains('\\')) {
        throw const FormatException('Saisissez une adresse IP ou un nom d’hôte valide, sans http:// ni chemin.');
      }
    }
    return ConnectionEndpoint._(host, port);
  }

  String get label => host.contains(':') ? '[$host]:$port' : '$host:$port';
}
