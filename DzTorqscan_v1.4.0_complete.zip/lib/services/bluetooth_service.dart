import 'dart:async';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:flutter_bluetooth_serial_plus/flutter_bluetooth_serial_plus.dart';
import 'package:permission_handler/permission_handler.dart';
import 'connection_endpoint.dart';

enum BluetoothConnectionState { disconnected, connecting, connected, error }

class BluetoothService extends ChangeNotifier {
  BluetoothConnection? _connection;
  Socket? _wifiSocket;
  String? _wifiEndpoint;
  BluetoothDevice? _connectedDevice;
  BluetoothConnectionState _state = BluetoothConnectionState.disconnected;
  String? _errorMessage;
  List<BluetoothDevice> _bondedDevices = [];

  BluetoothConnectionState get state => _state;
  BluetoothDevice? get connectedDevice => _connectedDevice;
  String get connectionLabel => _connectedDevice?.name ?? _wifiEndpoint ?? 'OBD';
  bool get isWifiConnected => _state == BluetoothConnectionState.connected && _wifiSocket != null && !_wifiSocket!.destroyed;
  String? get errorMessage => _errorMessage;
  List<BluetoothDevice> get bondedDevices => List.unmodifiable(_bondedDevices);
  bool get isConnected => _state == BluetoothConnectionState.connected && ((_connection?.isConnected ?? false) || (_wifiSocket != null && !_wifiSocket!.destroyed));
  Stream<Uint8List>? get inputStream => _connection?.input ?? _wifiSocket;

  Future<bool> requestPermissions() async {
    if (defaultTargetPlatform != TargetPlatform.android) return true;
    // This app connects only to devices already paired in Android settings.
    // Android 12+ requires BLUETOOTH_CONNECT for bonded-device access and RFCOMM;
    // BLUETOOTH_SCAN is unnecessary because this app does not discover nearby devices.
    final statuses = await [Permission.bluetoothConnect].request();
    final granted = statuses.values.every(
      (status) => status.isGranted || status.isLimited,
    );
    if (!granted) {
      _errorMessage = 'Autorisation Bluetooth refusée. Autorisez l’accès aux appareils Bluetooth appairés dans les paramètres Android.';
      _state = BluetoothConnectionState.error;
      notifyListeners();
    }
    return granted;
  }

  Future<bool> isBluetoothEnabled() async {
    try {
      return await FlutterBluetoothSerial.instance.isEnabled ?? false;
    } catch (_) {
      return false;
    }
  }

  Future<bool> enableBluetooth() async {
    try {
      return await FlutterBluetoothSerial.instance.requestEnable() ?? false;
    } catch (e) {
      _errorMessage = 'Impossible d’activer le Bluetooth : $e';
      notifyListeners();
      return false;
    }
  }

  Future<void> loadBondedDevices() async {
    try {
      _bondedDevices = await FlutterBluetoothSerial.instance.getBondedDevices();
      _bondedDevices.sort((a, b) {
        final ao = _looksLikeObd(a.name);
        final bo = _looksLikeObd(b.name);
        if (ao != bo) return ao ? -1 : 1;
        return (a.name ?? a.address).toLowerCase().compareTo((b.name ?? b.address).toLowerCase());
      });
      _errorMessage = null;
      notifyListeners();
    } catch (e) {
      _errorMessage = 'Erreur de lecture des appareils appairés : $e';
      notifyListeners();
    }
  }

  bool _looksLikeObd(String? name) {
    final n = (name ?? '').toUpperCase();
    return n.contains('OBD') || n.contains('ELM') || n.contains('V-LINK') || n.contains('VLINK') || n.contains('OBDII') || n.contains('OBD2');
  }

  Future<bool> connect(BluetoothDevice device) async {
    if (_state == BluetoothConnectionState.connecting) return false;
    await disconnect(notify: false);
    _state = BluetoothConnectionState.connecting;
    _connectedDevice = device;
    _errorMessage = null;
    notifyListeners();

    try {
      _connection = await BluetoothConnection.toAddress(device.address).timeout(const Duration(seconds: 15));
      _state = BluetoothConnectionState.connected;
      notifyListeners();
      return true;
    } catch (e) {
      _state = BluetoothConnectionState.error;
      _errorMessage = 'Échec de connexion à ${device.name ?? device.address} : $e';
      _connection = null;
      _connectedDevice = null;
      notifyListeners();
      return false;
    }
  }

  Future<bool> connectWifi(String host, int port) async {
    late final ConnectionEndpoint endpoint;
    try {
      endpoint = ConnectionEndpoint.parse(host, port);
    } on FormatException catch (e) {
      _errorMessage = e.message;
      notifyListeners();
      return false;
    }
    final normalizedHost = endpoint.host;
    if (_state == BluetoothConnectionState.connecting) return false;
    await disconnect(notify: false);
    _state = BluetoothConnectionState.connecting;
    _connectedDevice = null;
    _wifiEndpoint = endpoint.label;
    _errorMessage = null;
    notifyListeners();
    try {
      _wifiSocket = await Socket.connect(normalizedHost, port, timeout: const Duration(seconds: 8));
      _wifiSocket!.setOption(SocketOption.tcpNoDelay, true);
      _state = BluetoothConnectionState.connected;
      notifyListeners();
      return true;
    } catch (e) {
      try { _wifiSocket?.destroy(); } catch (_) {}
      _wifiSocket = null;
      _wifiEndpoint = null;
      _state = BluetoothConnectionState.error;
      _errorMessage = 'Échec de connexion Wi-Fi à $normalizedHost:$port : $e';
      notifyListeners();
      return false;
    }
  }

  /// Synchronizes the transport state when the underlying stream ends remotely.
  /// The OBD service owns the single stream subscription, so it reports EOF/errors here.
  void markTransportEnded({String? reason, bool failed = false}) {
    if (_state != BluetoothConnectionState.connected &&
        _state != BluetoothConnectionState.connecting) {
      return;
    }
    final connection = _connection;
    final socket = _wifiSocket;
    _connection = null;
    _wifiSocket = null;
    _connectedDevice = null;
    _wifiEndpoint = null;
    if (socket != null && !socket.destroyed) socket.destroy();
    if (connection != null) unawaited(connection.close());
    _state = failed ? BluetoothConnectionState.error : BluetoothConnectionState.disconnected;
    _errorMessage = reason;
    notifyListeners();
  }

  Future<void> disconnect({bool notify = true}) async {
    final connection = _connection;
    final socket = _wifiSocket;
    _connection = null;
    _wifiSocket = null;
    _connectedDevice = null;
    _wifiEndpoint = null;
    _state = BluetoothConnectionState.disconnected;
    try { await connection?.close(); } catch (_) {}
    try { await socket?.close(); } catch (_) { socket?.destroy(); }
    if (notify) notifyListeners();
  }

  Future<void> write(String data) async {
    final bytes = Uint8List.fromList(data.codeUnits);
    final socket = _wifiSocket;
    if (socket != null && !socket.destroyed) {
      socket.add(bytes);
      await socket.flush();
      return;
    }
    final connection = _connection;
    if (connection == null || !connection.isConnected) throw StateError('Adaptateur OBD2 non connecté');
    connection.output.add(bytes);
    await connection.output.allSent;
  }

  @override
  void dispose() {
    unawaited(disconnect(notify: false));
    super.dispose();
  }
}
